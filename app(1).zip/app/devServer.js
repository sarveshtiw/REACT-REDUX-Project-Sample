require('dotenv').config();
const port = process.env.PORT || 3000;

var path = require('path');
var express = require('express');
var webpack = require('webpack');
var config;

if (process.env.NODE_ENV === 'production') {
  config = require('./webpack.config.prod');
} else { 
  config = require('./webpack.config.dev');
}

var app = express();
var compiler = webpack(config);

app.use(require('webpack-dev-middleware')(compiler, {
  noInfo: true,
  publicPath: config.output.publicPath
}));

//
app.use(express.static(path.join(__dirname, 'public')));
//app.use('/node_modules/strophe.js', express.static('node_modules/strophe.js'));
app.use(require('webpack-hot-middleware')(compiler));

app.get('*', function(req, res) {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(port, function(err) {
  if (err) {
    //console.log(err);
    return;
  }

  console.log('App listening on port ', port);
  console.log(`Now browse to :${port}`);
});
