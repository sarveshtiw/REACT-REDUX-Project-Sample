var path = require('path');
var webpack = require('webpack');
var ExtractTextPlugin = require("extract-text-webpack-plugin");

module.exports = {
    devtool: 'source-map',
    entry: [
        'webpack-hot-middleware/client',
        './client/index'
    ],
    output: {
        path: path.join(__dirname, 'dist'),
        filename: 'bundle.js',
        publicPath: '/static/'
    },
    module: {
        loaders: [
            // JS
            {
                test: /\.js$/,
                loader: 'babel-loader',
                include: path.join(__dirname, 'client')
            },
            // CSS
            {
                test: /\.css$/,
                use: [{
                    loader: "style-loader"
                },
                {
                    loader: "css-loader",
                    options: {
                        sourceMap: true,
                        minimize: true
                    }
                },
                {
                    loader: "autoprefixer-loader"
                }
                ]
            },
            // SCSS
            {
                test: /\.scss$/,
                include: path.join(__dirname, 'client'),
                // use: ExtractTextPlugin.extract({
                // fallback: 'style-loader',
                use: [{
                    loader: "style-loader"
                },
                {
                    loader: "css-loader",
                    options: {
                        sourceMap: true,
                        minimize: true
                    }
                },
                {
                    loader: "autoprefixer-loader"
                },
                {
                    loader: "sass-loader",
                    options: {
                        sourceMap: true
                    }
                }
                ]
                // })
            },
        ]
    },
    plugins: [
        new webpack.HotModuleReplacementPlugin(),
        new webpack.NoEmitOnErrorsPlugin(),
        new webpack.DefinePlugin({
            'process.env': {
                'NODE_ENV': JSON.stringify(process.env.NODE_ENV),
                'API_URL': JSON.stringify(process.env.API_URL) || JSON.stringify('http://localhost:3000/mc-api'),
                'API_MINIO': JSON.stringify(process.env.API_MINIO) || JSON.stringify('http://localhost:3001'),
                'AMP_API': JSON.stringify(process.env.AMP_API) || JSON.stringify('http://192.168.100.210:8002')
            }
        }),
    ],
};
