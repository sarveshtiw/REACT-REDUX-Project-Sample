var path = require('path');
var webpack = require('webpack');

module.exports = {
    devtool: 'source-map',
    entry: [
        './client/index'
    ],
    output: {
        path: path.join(__dirname, 'dist'),
        filename: 'bundle.js',
        publicPath: '/static/'
    },
    plugins: [
        new webpack.optimize.OccurrenceOrderPlugin(),
        new webpack.DefinePlugin({
            'process.env': {
                'NODE_ENV': "'production'",
                'API_URL': JSON.stringify(process.env.API_URL) || JSON.stringify('https://development.asergiscloud.com/mc-api'),
                'API_MINIO': JSON.stringify(process.env.API_MINIO) || JSON.stringify('http://192.168.1.160:3000'),
                'AMP_API': JSON.stringify(process.env.AMP_API) || JSON.stringify('http://192.168.100.210:8002')
            }
        }),
        new webpack.optimize.UglifyJsPlugin({
            compressor: {
                warnings: false
            }
        })
    ],
    module: {
        loaders: [
            // JS
            {
                test: /\.js$/,
                loader: 'babel-loader',
                include: path.join(__dirname, 'client')
            },
            // CSS
            {
                test: /\.css$/,
                use: [{
                    loader: "style-loader"
                },
                {
                    loader: "css-loader",
                    options: {
                        sourceMap: true,
                        minimize: true
                    }
                },
                {
                    loader: "autoprefixer-loader"
                }
                ]
            },
            // SCSS
            {
                test: /\.scss$/,
                include: path.join(__dirname, 'client'),
                // use: ExtractTextPlugin.extract({
                // fallback: 'style-loader',
                use: [{
                    loader: "style-loader"
                },
                {
                    loader: "css-loader",
                    options: {
                        sourceMap: true,
                        minimize: true
                    }
                },
                {
                    loader: "autoprefixer-loader"
                },
                {
                    loader: "sass-loader",
                    options: {
                        sourceMap: true
                    }
                }
                ]
                // })
            },
        ]
    }
};
