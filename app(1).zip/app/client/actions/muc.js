import store from '../store';
import mucfilter from '../models/mucfilter';
import axios from 'axios';
import msgService from '../services/message';
//import rooms from '../data/rooms';
import configData from '../data/config';
var _ = require('underscore');

import {
	LIST_MUC,
	ADD_MUC,
	REMOVE_MUC,
	UPDATE_MUC,
	ACTIVE_MUC,
	GET_INVITATION_MUC,
	SEND_INVITATION_MUC,
	LEAVE_ROOM
} from '../constants';

export const getRooms = (values) => {
	return function (dispatch) {		
		axios({
			method: 'POST',
			url: configData.api_url + '/search',
			data: {
				'token': localStorage.token,
				'indexName': 'asergis', //searchIndex,
				'documentName': configData.document.user,
				'queryString': {
					"query": {
						"match_phrase": {
							"jid": localStorage.jid
						}
					}
				}
			},
			headers: {
				'content-Type': 'application/json'
			}
		})
		.then(function (response) {
			if (response.hasOwnProperty('data') && response.data.data.hits) {
				if(response.data.data.hits.total > 0) {
					let conf = mucfilter.filterRooms(response);
					let roomsList = mucfilter.getRoomsList(response);
					//console.log("@@@conf",conf);
					msgService.joinChannel(conf);
					
					dispatch({
						type: LIST_MUC,
						payload: {
							newVal: roomsList
						}
					})
				}
			}
		})
		.catch(function (error) {				
			console.log(error);
		});
	}
}

export const activeRoster = (values) => {
	return function (dispatch) {
		values.unread = 0;
		dispatch({
			type: ACTIVE_MUC,
			payload: {
				newVal: values
			}
		})
	}
}

export const getMucInvitation = (values) => {
	var data = mucfilter.addRoom(values);
	
	return function (dispatch) {
		axios({
			method: 'POST',
			url: configData.api_url + '/save',
			data: {
				'token': localStorage.token,
				'indexName': 'asergis', //searchIndex,
				'documentName': configData.document.user,
				'data': data[0]
			},
			headers: {
				'content-Type': 'application/json'
			}
		})
		.then(function (response) {			
			msgService.joinChannel(data);
			
			//dispatching request to reducer
			dispatch({
				type: GET_INVITATION_MUC,
				payload: {
					newVal: data[0].conference
				}
			})
		})
		.catch(function (error) {
			console.log(error);
		});
	}
}

export const updateMucFlag = (values) => {
    return function(dispatch){		
		var info = mucfilter.arrangeCaps(values);
		dispatch({
			type: UPDATE_MUC,
			payload: {
				newVal: info
			}
		})
    }
}

export const leaveRoom = (values) => {
	return function (dispatch) {
		axios({
			method: 'POST',
			url: configData.api_url + '/delete',
			data: {
				'token': localStorage.token,
				'indexName': 'asergis', //searchIndex,
				'documentName': configData.document.user,
				'queryString': {
					"query": {
						"match_phrase": {
							"conference.jid.bare": values.room
						},
					}
				}
			},
			headers: {
				'content-Type': 'application/json'
			}
		})
		.then(function (response) {	
			dispatch({
				type: LEAVE_ROOM,
				payload: {
					newVal: values.indexName
				}
			})
		})
		.catch(function (error) {				
			console.log(error);
		});
	}
}

export const updateRoomInfo = (values) =>  {
	return function (dispatch) {
		axios({
			method: 'POST',
			url: configData.api_url + '/update',
			data: {
				'token': localStorage.token,
				'indexName': 'asergis', 
				'documentName': configData.document.user,
				'queryString': {
					"script":{
						"source":"ctx._source.conference.description='"+ values.description + "'",
						"lang":"painless"
					},
					"query": {
						"match_phrase": {
							"conference.jid.bare": values.room
						},
					}
				}
			},
			headers: {
				'content-Type': 'application/json'
			}
		})
		.then(function (response) {	
			dispatch({
				type: "UPDATE_ROOM_INFO",
				payload: {
					newVal: values.keyIndex, 
					description: values.description
				}
			})
		})
		.catch(function (error) {				
			console.log(error);
		});
	}
}

//save details into db and send invitations
export const sendMucInvitation = (values) => {
	//create conference object format
	var data = mucfilter.selfJoinRoom(values);
	
	//join and send invitation, notification	
	return function (dispatch) {
		axios({
			method: 'POST',
			url: configData.api_url + '/save',
			data: {
				'token': localStorage.token,
				'indexName': 'asergis', //searchIndex,
				'documentName': configData.document.user,
				'data': data[0]
			},
			headers: {
				'content-Type': 'application/json'
			}
		})
		.then(function (response) {
			msgService.joinChannel(data);

			var reqParams = [];
			_.each(values.contacts, function (contact) {		
				//send invitation and notification
				client.directInvite(data[0].conference.jid.bare, { to: contact, reason: values.purpose });
			
				reqParams.push({
					toUser: contact,
					from: localStorage.name,
					subject: 'Notification from Message Centre',
					desc: values.purpose
				});						
			});

			//send notification
            msgService.sendNotification(reqParams, 'MUC_INVITATION');
			
			//dispatching request to reducer
			dispatch({
				type: GET_INVITATION_MUC,
				payload: {
					newVal: data[0].conference
				}
			})
		})
		.catch(function (error) {
			console.log(error);
		});
	}
}
