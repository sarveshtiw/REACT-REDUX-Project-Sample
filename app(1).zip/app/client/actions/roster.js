import Contacts from '../models/contacts';
import store from '../store';
import { LIST_CONTACT, ADD_CONTACT, REMOVE_CONTACT, UPDATE_CONTACT, ACTIVE_CONTACT } from '../constants';
import axios from 'axios';
import configData from '../data/config';

export const getRoster = (data) => {
	return function(dispatch){
		var contacts = [];
		contacts = Contacts.fliterContacts(contacts, data);
		dispatch({
			type: LIST_CONTACT,
			payload: {
				newVal: contacts
			}
		})
  	}
}

export const updateRosterFlag = (values) => {
    return function(dispatch){
		var oldContacts = store.getState().roster.all;
		if(oldContacts){
			var contacts = Contacts.fliterContacts(oldContacts, values);
			dispatch({
				type: UPDATE_CONTACT,
				payload: {
					newVal: contacts
				}
			})
		}
    }
}

// function used for show active roster data and countRoommembers in active room.
export const activeRoster = (values) => {
    return function(dispatch){
		values.unread = 0;
		values.countRoomMembers = 0;
		if(values.role || values.affiliation || values.description) {
			axios({
				method: 'POST',
				url: configData.api_url + '/search',
				data: {
					'token': localStorage.token,
					'indexName': 'asergis',
					'documentName': configData.document.user,
					'queryString': {
						"query": {
							"match_phrase": { 
								"conference.jid.bare": values.jid.bare
							}
						},
					}
				},
				headers: { 'content-Type': 'application/json' }
			})
			.then(function (response) {
				values.countRoomMembers = response.data.data.hits.hits.length;
				dispatch({
					type: ACTIVE_CONTACT,
					payload: {
						newVal: values,
						countRoomMembers: values.countRoomMembers
					}
				})
			})
			.catch(function (error) {
				console.log(error);
			});
		}else{
			dispatch({
				type: ACTIVE_CONTACT,
				payload: {
					newVal: values
				}
			})
		}
    }
}
