import modelmessage from './../models/messagefilter';
import msgService from './../services/message';
import store from '../store';
import configData from '../data/config';
import axios from 'axios';
import {
    CHAT_HISTORY,
    CHAT_OUTGOING,
    CHAT_INCOMING,
    CHAT_REMOVE,
    CHAT_UPDATE,
    CHAT_SEARCH,
    CHAT_MSG_UPDATE
} from '../constants';

//load chat messages from history on page loads 
export const getChatMessages = (data, length, scrollId) => {
    var result = {};
    return function (dispatch) {
        axios({
            method: 'POST',
            url: configData.api_url + '/cursor-search',
            data: {
                'token': localStorage.token,
                'indexName': 'asergis', //searchIndex,
                'documentName': configData.document.chat,                
                'queryString': {
                    "query": {
                        "bool": {
                            "should": [{
                                "bool": {
                                    "must": [{
                                        "match_phrase": {
                                            "from.jid": localStorage.jid
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "to.jid": data.jid.bare
                                        }
                                    }],
                                    "must_not": {
                                        "exists": {"field": "isDeleted"}
                                    }
                                }
                            },
                            {
                                "bool": {
                                    "must": [{
                                        "match_phrase": {
                                            "from.jid": data.jid.bare
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "to.jid": localStorage.jid
                                        }
                                    }],
                                    "must_not": {
                                        "exists": {"field": "isDeleted"}
                                    }
                                }
                            }],
                            "minimum_should_match": 1
                        }
                    },
                    "scroll": "1m",
                    "scroll_id": scrollId ? scrollId : '',
                    //"from": length,
                    "size": 10,
                    "sort": [{
                        "createdOn":"desc"
                    }],
                    
                }
            },
            headers: {
                'content-Type': 'application/json'
            }
        })
        .then(function (response) {
            result = modelmessage.arrangeMessageHistory(response);
            dispatch({
                type: CHAT_HISTORY,
                payload: {
                    newVal: result.data,
                    total: result.total,
                    scrollId: result.scrollId,
                    length: length
                }
            })
        })
        .catch(function (error) {
            console.log(error);
        });
    }
}

//add message to elastic and send to respective user
export const addMessage = (values, notification) => {
    //send message
    var msgid = client.sendMessage(values);
    var messages = Object.assign(values, {
        msgid: msgid
    });
    var messagesarr = modelmessage.arrangeOutgoingMsg(messages);
    //dispatch action
    if (msgid) {

        //send notification
        if (notification && Object.keys(notification).length > 0) {
            msgService.sendNotification(notification, 'CHAT_MENTION');
        }

        return function (dispatch) {
            axios({
                method: 'POST',
                url: configData.api_url + '/save',
                data: {
                    'token': localStorage.token,
                    'indexName': 'asergis',//searchIndex,
                    'documentName': configData.document.chat,
                    'data': messagesarr
                },
                headers: { 'content-Type': 'application/json' }
            })
            .then(function (response) {
                dispatch({
                    type: CHAT_OUTGOING,
                    payload: {
                        newVal: messagesarr
                    }
                })
            })
            .catch(function (error) {
                console.log(error);
            });
        }
    }
}

//add message to elastic and send to respective user
export const updateMessage = (values, notification) => {
    //send message
    var msgid = client.sendMessage(values);
    var messages = Object.assign(values, {
        msgid: Object.keys(values.oldMessage).length ? values.oldMessage.id : msgid,
    });
    var messagesarr = modelmessage.arrangeOutgoingMsg(messages);    
    
    if (msgid) {

        //send notification
        if (notification && Object.keys(notification).length > 0) {
            msgService.sendNotification(notification);
        }

        return function (dispatch) {
            var isEdited = true;
            var value = "ctx._source.isEdited="+isEdited+";ctx._source.body='" + messagesarr.body + "'";
    
            axios({
                method: 'POST',
                url: configData.api_url + '/update',
                data: {
                    'token': localStorage.token,
                    'indexName': 'asergis',
                    'documentName': configData.document.chat,
                    'queryString': {
                        "script":{
                            "source":value,
                            "lang":"painless"
                        },
                        "query":{
                            "match_phrase":{
                                "id": messagesarr.id
                            }
                        }
                    }
                },
                headers: { 'content-Type': 'application/json' }
            })
            .then(function (response) {
                dispatch({
                    type: CHAT_UPDATE,
                    payload: {
                        newVal: messagesarr
                    }
                })			
            })
            .catch(function (error) {
                console.log(error);
            });
        }
    }
}


//receive incoming messages from anywhere
export const incomingMessages = (values) => {
    var messagesarr = modelmessage.arrangeIncomingMsg(values);

    //send request to reducer
    return function (dispatch) {
        dispatch({
            type: CHAT_INCOMING,
            payload: {
                newVal: messagesarr,
            }
        })
    }
}

//send attachment to any user
export const sendAttachment = (messageArr, file) => {
    return function (dispatch) {
        const formImageData = new FormData();
        formImageData.append("file", file)
        formImageData.append("asergisPopId", "india");

        return axios({
            async: true,
            crossdomain: true,
            url: configData.api_minio + '/file-upload',
            method: 'POST',
            headers: {
                'token': localStorage.token
            },
            processData: false,
            contentType: 'multipart/form-data',
            data: formImageData
        })
        .then(function (response) {
            var responseArr = Object.assign(messageArr, {
                body: response.data.data.fileId
            });
            var msgid = client.sendMessage(responseArr);
            var messages = Object.assign(responseArr, {
                msgid: msgid
            });
            var messagesarr = modelmessage.arrangeOutgoingMsg(messages);

            if (msgid) {
                var chatMessageArr = Object.assign(messagesarr, {
                    isAttachment: true
                });
                msgService.saveToElastic(chatMessageArr);
                dispatch({
                    type: CHAT_OUTGOING,
                    payload: {
                        newVal: messagesarr
                    }
                });
            }

        })
        .catch(function (error) {
            console.log(error);
        });
    }
}

//searching messages from elasic index
export const searchMessages = (value) => {
    return function (dispatch) {
        var query = modelmessage.searchQuery(value);
        
        axios({
            method: 'POST',
            url: configData.api_url + '/search',
            data: {
                'token': localStorage.token,
                'indexName': 'asergis', //searchIndex,
                'documentName': configData.document.chat,
                'queryString': query
            },
            headers: {
                'content-Type': 'application/json'
            }
        })
        .then(function (response) {
            var messages = modelmessage.arrangeSerachResult(response);
            
            //send request to reducer
            dispatch({
                type: CHAT_SEARCH,
                payload: {
                    newVal: messages
                }
            })
        })
        .catch(function (error) {
            console.log(error);
        });
    }
}

//delete any sent message
export const deleteMessages = (value) => {
    return function (dispatch) {
        msgService.updateChatInfo({id: value.id, isDeleted: true});
        
        //send request to reducer
        dispatch({
            type: CHAT_REMOVE,
            payload: {
                newVal: value
            }
        })
    }
}

//fetch message and set for edit 
export const setMessages = (value) => {
    return function (dispatch) {
        
        //send request to reducer
        dispatch({
            type: CHAT_MSG_UPDATE,
            payload: {
                newVal: value ? value : {}
            }
        })
    }
}