import modelmessage from './../models/messagefilter';
import msgService from './../services/message';
import store from '../store';
import configData from '../data/config';
import axios from 'axios';
import {
    CHAT_ATTACHMENTS,
    CHAT_FAVOURITES
} from '../constants';

export const getChatMessagesByCategory = (data, length, scrollId) => {
    var keyIndex = ''; 
    var dispatch_action = '';
    if(data.isAttachment) {
        keyIndex = "isAttachment";
        dispatch_action = CHAT_ATTACHMENTS;
    } else {
        keyIndex = "isFavourite";
        dispatch_action = CHAT_FAVOURITES;
    }    
    var result = {};
    
    return function (dispatch) {
        axios({
            method: 'POST',
            url: configData.api_url + '/cursor-search',
            data: {
                'token': localStorage.token,
                'indexName': 'asergis', //searchIndex,
                'documentName': configData.document.chat,                
                'queryString': {
                    "query": {
                        "bool": {
                            "should": [{
                                "bool": {
                                    "must": [{
                                        "match_phrase": {
                                            "from.jid": localStorage.jid
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "to.jid": data.jid.bare
                                        }
                                    }],
                                    "must_not": {
                                        "exists": {"field": "isDeleted"}
                                    }
                                }
                            },
                            {
                                "bool": {
                                    "must": [{
                                        "match_phrase": {
                                            "from.jid": data.jid.bare
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "to.jid": localStorage.jid
                                        }
                                    }],
                                    "must_not": {
                                        "exists": {"field": "isDeleted"}
                                    }
                                }
                            }],
                            "minimum_should_match": 1
                        }
                    },
                    "scroll": "1m",
                    "scroll_id": scrollId ? scrollId : '',
                    //"from": length,
                    "size": 10,
                    "sort": [{
                        "createdOn":"desc"
                    }],
                    
                }
            },
            headers: {
                'content-Type': 'application/json'
            }
        })
        .then(function (response) {
            result = modelmessage.arrangeMessageHistory(response);
            dispatch({
                type: dispatch_action,
                payload: {
                    newVal: result.data,
                    total: result.total,
                    length: length
                }
            })
        })
        .catch(function (error) {
            console.log(error);
        });
    }
}

