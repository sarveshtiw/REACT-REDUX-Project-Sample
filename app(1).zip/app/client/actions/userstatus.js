import modelmessage from './../models/messagefilter';
import msgService from './../services/message';
import axios from 'axios';
import configData from '../data/config';
import { 
	USER_STATUS_UPDATE
} from '../constants';

export const updateUserStatus = (status, quote, data) => {
    var statusArr = modelmessage.userStatus(status, quote, data);
	return function (dispatch) {        
        axios({
            method: 'POST',
            url: configData.api_url + '/search',
            data: {
                'token': localStorage.token,
                'indexName': 'asergis',//searchIndex,
                'documentName': configData.document.user,
                'queryString': {
                    "query": {
                        "match_phrase": { 
							"personalinfo.jid": localStorage.jid  
						}
                    },
                }
            },
            headers: { 'content-Type': 'application/json' }
        })
        .then(function (response) {
			if(response.data.data.hits.total > 0){
				//update userinfo in elastic
                msgService.updatePersonalInfo(statusArr);
               
			}else{
				//insert userinfo
                msgService.insertPersonalInfo(statusArr);
            }
            
            //send presence to users
            client.sendPresence({
                status: statusArr.personalinfo.status,
                show: statusArr.personalinfo.showtypes,
                caps: client.disco.caps
            });

            //dispatch status
            dispatch({
                type: USER_STATUS_UPDATE,
                payload: {
                    newVal: statusArr.personalinfo
                }
            })
        })
        .catch(function (error) {
            console.log(error);
		});
    }
}

export const getUserStatus = () => {
	return function (dispatch) {  
             
        axios({
            method: 'POST',
            url: configData.api_url + '/search',
            data: {
                'token': localStorage.token,
                'indexName': 'asergis',//searchIndex,
                'documentName': configData.document.user,
                'queryString': {
                    "query": {
                        "match_phrase": { 
							"personalinfo.jid": client.jid.bare  
						}
                    },
                }
            },
            headers: { 'content-Type': 'application/json' }
        })
        .then(function (response) {            
			if(response.data.data.hits.total > 0){
                var statusArr = response.data.data.hits.hits[0]._source;
                
            }else{
                //insert userinfo
                var statusArr = modelmessage.userStatus('chat', '');
                msgService.insertPersonalInfo(statusArr);
            }

            //send presence to users
            var caps = client.updateCaps();
            client.sendPresence({
                status: statusArr.personalinfo.status,
                show: statusArr.personalinfo.showtypes,
                caps: client.disco.caps
            });
            client.enableCarbons();

            //dispatch status
            dispatch({
                type: USER_STATUS_UPDATE,
                payload: {
                    newVal: statusArr.personalinfo
                }
            })
        })
        .catch(function (error) {
            console.log(error);
		});
    }
}

export const userLogout = () => {
	return function () {
        axios({
            method: 'POST',
            url: configData.amp_api + '/user-logout',
            crossdomain: true,
            data: { 'token': localStorage.token },
            headers: { "Content-Type": "application/json" }
        })
        .then(function (response) {
            if(response.status == '200' && response.statusText == 'OK'){
                window.location.assign('https://development.asergiscloud.com');               
            }else{
                return 0;
            }           
        })
        .catch(function (error) {
            console.log(error);
        });
    }
}

