import modelmessage from './../models/messagefilter';
import msgService from '../services/message';
import configData from '../data/config';
import axios from 'axios';
import { 
    NOTIFICATION_ADD,
	NOTIFICATION_STATUS,
	NOTIFICATION_HISTORY,
} from '../constants';

export const getNotifications = (values) => {
	return function (dispatch) {		
		axios({
			method: 'POST',
			url: configData.api_url + '/search',
			data: {
				'token': localStorage.token,
				'indexName': 'asergis',//searchIndex,
				'documentName': configData.document.notifications,
				'queryString': {
					"query": {
						"match_phrase": {
							"to.bare": client.jid.bare
						}
					},
					"from": 0,
					"size": 10,
					"sort": {
						"createdOn": "desc"
					}
				}	
			},
			headers: { 'content-Type': 'application/json' }
		})
		.then(function (response) {
			var notifications = modelmessage.arrangeNotificationHistory(response);
			dispatch({
				type: NOTIFICATION_HISTORY,
				payload: {
					newVal: notifications
				}
			})
		})
		.catch(function (error) {
			console.log(error);
		});
	}
}

export const addNotification = (values) => {
    let message = modelmessage.incomingNotification(values);
	return function (dispatch) {		
		axios({
			method: 'POST',
			url: configData.api_url + '/save',
			data: {
				'token': localStorage.token,
				'indexName': 'asergis',//searchIndex,
				'documentName': configData.document.notifications,
				'data': message
			},
			headers: { 'content-Type': 'application/json' }
		})
		.then(function (response) {
			dispatch({
				type: NOTIFICATION_ADD,
				payload: {
					newVal: message
				}
			})
		})
		.catch(function (error) {
			console.log(error);
		});
	}
}

export const updateFlag = (value) => {
	return function (dispatch) {
		var updateData = "ctx._source.status=0";
		var where = value && Object.keys(value).length ? {"id": value.id} : {"to.bare": client.jid.bare};
		axios({
			method: 'POST',
			url: configData.api_url + '/update',
			data: {
				'token': localStorage.token,
				'indexName': 'asergis',
				'documentName': configData.document.notifications,
				'queryString': {
					"script":{
						"source":updateData,
						"lang":"painless"
					},
					"query":{
						"match_phrase":where
					}
				}
			},
			headers: { 'content-Type': 'application/json' }
		})
		.then(function (response) {
			dispatch({
				type: NOTIFICATION_STATUS,
				payload: {
					newVal: value
				}
			})		
		})
		.catch(function (error) {
			console.log(error);
		});
	}
}

export const inviteUsers = (users, groupusers) => {
	if(groupusers){
		var userData = modelmessage.getUsersFromGroup(users);
	}else{
		var userData = modelmessage.getUsersFromArray(users);
	}
	msgService.sendInvitationToUsers(userData);

	return function () {
		
	}
}