/*global app, me, client*/

var _ = require('underscore');
var Moment = require('moment');

module.exports = {

    arrangeIncomingMsg: function (data) {
        //create new contact list
        var messages = [];

        var fromname = data.from.name !== undefined ? data.from.name : data.from.local;
        var toname = data.to.name !== undefined ? data.to.name : '';
        var fromchannel = data.from.bare !== undefined ? data.to.name : '';

        let userjid = data.type == 'chat' ? data.from.bare : data.from.resource;
        messages = {
            body: data.body,
            from: { name: fromname, jid: userjid, channel: data.from.bare },
            to: { name: toname, jid: data.to.bare },
            type: data.type,
            id: data.id,
            time: new Date(),
        };

        return messages;
    },
    arrangeOutgoingMsg: function (data) {
        console.log('sending', data);
        //create new contact list
        var messagesarr = [];
        var fromname = data.fromname;
        var toname = data.toname;

        messagesarr = {
            body: data.body,
            from: { name: fromname, jid: data.from },
            to: { name: toname, jid: data.to },
            type: data.type,
            id: data.msgid,
            time: new Date()
        };

        return messagesarr;
    },
    incomingNotification: function (data) {
        //create new contact list
        let arr = [];
        //let msg = data.from.local + ' has mentioned your name in a chat.';
        arr = {
            body: data.body,
            from: { bare: data.from.bare, full: data.from.full, local: data.from.local },
            to: { bare: data.to.bare, full: data.to.full, local: data.to.local },
            type: data.type,
            id: data.id,
            status: 1,
            time: new Date()
        };

        return arr;
    },
    arrangeMessageHistory: function (response) {
        var messagesarr = [];
        if (response.hasOwnProperty('data') && response.data.data.hits) {
            if (response.data.data.hits.total > 0) {
                _.each(response.data.data.hits.hits, function (item) {
                    messagesarr.push(item._source);
                });
            }
        }
        //console.log("messagesarr",messagesarr);
        return { data: messagesarr, total: response.data.data.hits.total, scrollId: response.data.data._scroll_id };
    },
    userStatus: function (showtypes, quote, data) {
        var userstatus = {};
        userstatus = {
            personalinfo: {
                jid: localStorage.jid,
                status: quote,
                showtypes: showtypes,
                fullName: (data && data.fullName) ? data.fullName : '',
                displayName: (data && data.displayName) ? data.displayName : '',
                cap: client.disco.caps
            }
        }
        return userstatus;
    },
    getUsersFromGroup(users) {
        var userArr = users.split(',');
        return userArr;
    },
    getUsersFromArray(users) {
        var userArr = []; var to = ''; var id = '';

        Object.keys(users || {}).map((keyName, keyIndex) => {
            id = users[keyIndex].id;
            to = users[keyIndex]['useremail_' + id];
            name = users[keyIndex]['username_' + id];
            userArr.push({ to: to, name: name });
        });
        return userArr;
    },
    setChatBodyFormat: function (chatArray, return_url) {
        var body = '';
        var regexHttp = /(http|https):\/\/(\w+:{0,1}\w*)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%!\-\/]))?/;
        var regexImg = /\.(jpe?g|png|gif|bmp)$/i;
        var regexPdf = /\.(pdf)$/i;
        var regexDoc = /\.(doc|docx|odt)$/i;
        var regexXsl = /\.(xls|xlsx|csv)$/i;
        var regexDomain = /\.(co.in|co.uk|com|org|net|int|edu|gov|mil|arpa)$/i;

        if (chatArray.hasOwnProperty("isAttachment") && chatArray.isAttachment === true) {
            if (regexImg.test(chatArray.body)) {
                body = "<a href='" + return_url + "' target='_blank'><img src='" + return_url + "' alt='loading' /></a><span class='corner-left-top'></span><span class='corner-left-bot'></span>";
            } else if (regexPdf.test(chatArray.body)) {
                body = "<a href='" + return_url + "' target='_blank'><img src='/images/icons/pdf.svg' alt='loading' width='100px' /></a>";
            } else if (regexDoc.test(chatArray.body)) {
                body = "<a href='" + return_url + "' target='_blank'><img src='/images/icons/doc.svg' alt='loading' width='100px' /></a>";
            } else if (regexXsl.test(chatArray.body)) {
                body = "<a href='" + return_url + "' target='_blank'><img src='/images/icons/xls.svg' alt='loading' width='100px' /></a>";
            } else {
                body = "<a href='" + return_url + "' target='_blank'><img src='/images/icons/download-icon.png' alt='loading' width='100px' /></a>";
            }
        } else if (regexHttp.test(chatArray.body)) {
            let chatBody = chatArray.body.split(' ');
            let chatStr = '';
            for (var i = 0; i < chatBody.length; i++) {
                chatStr = chatStr + " ";
                if (regexHttp.test(chatBody[i])) {
                    chatStr += "<a class='link' href='" + chatBody[i] + "' target='_blank'>" + chatBody[i] + "</a>";
                } else {
                    chatStr += chatBody[i];
                }
            }
            body = "<p>" + chatStr + '</p>';
        } else if (regexDomain.test(chatArray.body)) {
            let chatBody = chatArray.body.split(' ');
            let chatStr = '';
            for (var i = 0; i < chatBody.length; i++) {
                chatStr = chatStr + " ";
                if (regexDomain.test(chatBody[i])) {
                    chatStr += "<a class='link' href='" + "http://" + chatBody[i] + "' target='_blank'>" + chatBody[i] + "</a>";
                } else {
                    chatStr += chatBody[i];
                }
            }
            body = "<p>" + chatStr + '</p>';
        } else { //<a class='material-icons editCancel'>close</a>
            var isEdited = chatArray.hasOwnProperty("isEdited") ? "<i class='material-icons edited'>mode_edit</i>" : '';
            body = isEdited + "<p>" + chatArray.body + '</p>';
        }
        return body;
    },
    setDataFormat: function (datetime, dateArr) {
        //for time header
        var msgtime;
        if (Moment(datetime).format('MMMM, dddd Do') == Moment().format('MMMM, dddd Do')) {
            msgtime = 'Today';

        } else if (Moment(datetime).format('MMMM, dddd Do') == Moment().add(-1, 'days').format('MMMM, dddd Do')) {
            msgtime = 'Yesterday';

        } else {
            msgtime = Moment(datetime).format('MMMM, dddd Do');
        }
        var timeheader = false;

        //update date in array
        if (dateArr.indexOf(msgtime) == -1) {
            dateArr.push(msgtime);

            timeheader = true;
        } else {
            timeheader = false;
        }

        return { msgtime: msgtime, timeheader: timeheader, shorttime: Moment(datetime).format('hh:mm A') }
    },
    arrangeSerachResult: function (response) {
        var messagesarr = [];
        if (response.hasOwnProperty('data') && response.data.data.hits) {
            if (response.data.data.hits.total > 0) {
                _.each(response.data.data.hits.hits, function (item) {
                    messagesarr.push(item._source);
                });
            }
        }
        //console.log(messagesarr);
        return messagesarr;
    },
    searchQuery: function (text) {
        var search = text.split(':');

        // if search case is 'from: khushboo: hello'
        if (search[0] == 'from' && search[1].length > 0 && search[2].length) {
            var query = {
                "query": {
                    "bool": {
                        "must": [{
                            "match_phrase": {
                                "from.jid": search[1].trim() + '@asergis.com'
                            }
                        },
                        {
                            "match": {
                                "body": search[2].trim()
                            }
                        }]
                    },
                },
                //"from": 0,
                //"size": 20,
                "sort": {
                    "createdOn": "asc"
                },
            }

            return query;

            // if search case is 'in-group: abcgroup: hello'
        } else if (search[0] == 'in-group' && search[1].length > 0 && search[2].length) {
            var query = {
                "query": {
                    "bool": {
                        "should": [{
                            "bool": {
                                "must": [{
                                    "match_phrase": {
                                        "from.jid": search[1].trim() + '@conference.asergis.com'
                                    }
                                },
                                {
                                    "match": {
                                        "body": search[2].trim()
                                    }
                                }]
                            }
                        },
                        {
                            "bool": {
                                "must": [{
                                    "match_phrase": {
                                        "to.jid": search[1].trim() + '@conference.asergis.com'
                                    }
                                },
                                {
                                    "match": {
                                        "body": search[2].trim()
                                    }
                                }]
                            }
                        }],
                        "minimum_should_match": 1
                    }
                },
                //"from": 0,
                //"size": 20,
                "sort": {
                    "createdOn": "asc"
                },
            }

            return query;

            // if search case is 'in-group: abcgroup: hello'
        } else if (search[0] == 'in-member' && search[1].length > 0 && search[2].length) {
            var query = {
                "query": {
                    "bool": {
                        "should": [{
                            "bool": {
                                "must": [{
                                    "match_phrase": {
                                        "from.jid": search[1].trim() + '@asergis.com'
                                    }
                                },
                                {
                                    "match": {
                                        "body": search[2].trim()
                                    }
                                }]
                            }
                        },
                        {
                            "bool": {
                                "must": [{
                                    "match_phrase": {
                                        "to.jid": search[1].trim() + '@asergis.com'
                                    }
                                },
                                {
                                    "match": {
                                        "body": search[2].trim()
                                    }
                                }]
                            }
                        }],
                        "minimum_should_match": 1
                    }
                },
                //"from": 0,
                //"size": 20,
                "sort": {
                    "createdOn": "asc"
                },
            }

            return query;

            // if search case is 'in-group: abcgroup: hello'
        } else if ((search[0] == 'after' || search[0] == 'before' || search[0] == 'on-date') && search[1].length > 0) {
            var type = (search[0] == 'after' ? 'gte' : (search[0] == 'before' ? 'lte' : 'gte'));

            var query = {
                "query": {
                    "bool": {
                        "should": [{
                            "bool": {
                                "must": [{
                                    "match_phrase": {
                                        "from.jid": localStorage.jid
                                    }
                                },
                                {
                                    "range": {
                                        "createdOn": {
                                            [type]: search[1].trim(),
                                            "format": "MM/dd/yyyy"
                                        }
                                    }
                                }],
                                "must_not": {
                                    "exists": { "field": "isAttachment" }
                                }
                            }
                        },
                        {
                            "bool": {
                                "must": [{
                                    "match_phrase": {
                                        "to.jid": localStorage.jid
                                    }
                                },
                                {
                                    "range": {
                                        "createdOn": {
                                            [type]: search[1].trim(),
                                            "format": "MM/dd/yyyy"
                                        }
                                    }
                                }],
                                "must_not": {
                                    "exists": { "field": "isAttachment" }
                                }
                            }
                        }],
                        "minimum_should_match": 1
                    }
                },
                //"from": 0,
                //"size": 20,
                "sort": {
                    "createdOn": "asc"
                },
            }

            return query;
        } else {
            var query = {
                "query": {
                    "bool": {
                        "should": [{
                            "bool": {
                                "must": [{
                                    "match_phrase": {
                                        "from.jid": search[1].trim() + '@asergis.com'
                                    }
                                },
                                {
                                    "match": {
                                        "body": search[2].trim()
                                    }
                                }]
                            }
                        },
                        {
                            "bool": {
                                "must": [{
                                    "match_phrase": {
                                        "to.jid": search[1].trim() + '@asergis.com'
                                    }
                                },
                                {
                                    "match": {
                                        "body": search[2].trim()
                                    }
                                }]
                            }
                        }],
                        "minimum_should_match": 1
                    }
                },
                //"from": 0,
                //"size": 20,
                "sort": {
                    "createdOn": "asc"
                },
            }

            return query;
        }
    },
    arrangeNotificationHistory: function (response) {
        var notificationssarr = [];
        if (response.hasOwnProperty('data') && response.data.data.hits) {
            if (response.data.data.hits.total > 0) {
                _.each(response.data.data.hits.hits, function (item) {
                    var id = item._source.id;
                    notificationssarr[id] = item._source;
                });
            }
        }
        //console.log("messagesarr",notificationssarr);
        return notificationssarr;
    },
    activeNotifications: function (response) {
        var notificationssarr = []; var i = 0;
        Object.keys(response.all || {}).map((keyName, keyIndex) => {
            if (response.all[keyName].status == 1) {
                var id = response.all[keyName].id;
                notificationssarr[id] = response.all[keyName];
                if (keyIndex == 2) {
                    return false;
                }
            }
        });

        return notificationssarr;
    },
};
