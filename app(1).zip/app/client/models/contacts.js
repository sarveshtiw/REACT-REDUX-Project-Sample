var _ = require('underscore');

module.exports = {

    fliterContacts: function (contacts, data) {
        
        var numContacts = Object.keys(contacts).length;
        if(numContacts == 0){
            //create new contact list
           // _.each(data, function(item) {
                Object.keys(data || {}).map((keyName, keyIndex) => {
                //client.subscribe(item.jid.bare);
                //data[keyIndex].
                contacts.push({
                    jid: data[keyIndex].jid,
                    name: data[keyIndex].name ? data[keyIndex].name : data[keyIndex].jid.bare,
                    domain: data[keyIndex].jid.domain,
                    group: data[keyIndex].groups[0],
                    unread: 0,
                    status: '',
                    showtypes: ''
                });
            });

        }else{

            for( var k = 0; k < numContacts; k++ ) {

                for(var i=0; i < data.length; i++){
                    if(data[i][contacts[k]['jid'].bare] !== undefined){
                        contacts[k]['status'] = data[i][contacts[k]['jid'].bare]['status'];
                        contacts[k]['full'] = data[i][contacts[k]['jid'].bare]['full'];
                        contacts[k]['showtypes'] = data[i][contacts[k]['jid'].bare]['showtypes'];
                    }else{
                        //contacts[k]['status'] = 'unavailable';
                    }
                }
            }
        }

        return contacts;
    },

    updateContacts(){

    },

    setContacts: function(contacts){

    }

};
