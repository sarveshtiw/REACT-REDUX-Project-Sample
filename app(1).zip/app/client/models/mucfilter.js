
var _ = require('underscore');

module.exports = {

    getRoomsList: function (response) {
        var totalRooms = Object.keys(response.data.data.hits.hits).length;
        var roomLists = [];
        if(totalRooms > 0)
        {
            // used for new rooms array lists
            _.each(response.data.data.hits.hits, function(val) {
                var item = val._source.conference;
                roomLists.push({
                    name: item.jid.local,
                    jid: item.jid,
                    nick: item.jid.local,
                    autoJoin: true,
                    unread: 0,
                    description: item.description,
                    role: item.role,
                    affiliation: item.affiliation
                });
            });
        }
       // console.log("@@roomLists",roomLists);
      return roomLists;
    },

    filterRooms: function (response) {
        var totalRooms = Object.keys(response.data.data.hits.hits).length;
        var roomLists = [];
        if(totalRooms > 0)
        {
            // used for new rooms array lists
            _.each(response.data.data.hits.hits, function(val) {
                var item = val._source;
                roomLists.push(item);
            });
        }
      return roomLists;
    },
    
    addRoom: function(item){
        var totalRooms = Object.keys(item).length;
        let roomLists = {};
        
        //console.log("@@@item",item);
        if(totalRooms > 0){
            var role = (item.from.bare === localStorage.jid || item.from.bare == '' ? 'moderator' : 'participant');
            var affiliation = (item.from.bare === localStorage.jid || item.from.bare == '' ? 'owner' : '');
            var value = [{
                jid: localStorage.jid,
                conference:{
                    name: item.room.local,
                    jid: { 
                        bare: item.room.bare, 
                        local: item.room.local 
                    },
                    nick: item.room.local,
                    autoJoin: true,
                    unread: 0,
                    description: item.reason,
                    password: item.password,
                    role: role,
                    affiliation: affiliation,                    
                }
            }];
            roomLists = Object.assign({}, value);
        }
        return roomLists;
    },
    selfJoinRoom: function(values){
        let roomLists = {};
        var value = [{
            jid: localStorage.jid,
            conference:{
                name: values.name,
                jid: { 
                    bare: values.name + '@conference.asergis.com', 
                    local: values.name 
                },
                nick: localStorage.name.replace(/[^A-Z0-9]+/ig, ''),
                autoJoin: true,
                unread: 0,
                description: values.purpose,
                password: '',
                role: '',
                affiliation: '',                
            }
        }];
        roomLists = Object.assign({}, value);
        return roomLists;
    },
    updateRoomInfo: function(contacts, data){
        
        console.log(contacts, data);
        /*
        for( var k = 0; k < numContacts; k++ ) {            
            for(var i=0; i < data.length; i++){
                if(data[i][contacts[k]['jid'].bare] !== undefined){
                    contacts[k]['status'] = data[i][contacts[k]['jid'].bare]['status'];
                    contacts[k]['full'] = data[i][contacts[k]['jid'].bare]['full'];
                }else{
                    //contacts[k]['status'] = 'unavailable';
                }
            }
        }
        */
    },
    arrangeCaps(pres){
        var values = {};

        values = {
            muc: { 
                affiliation: pres.muc.affiliation, 
                role: pres.muc.role,
                jid: pres.muc.jid,
                showtypes: pres.status 
            },            
            full: pres.from.full,
            bare: pres.from.bare,
            status: pres.type,
            resource: pres.resource,
            local: pres.local
        };

        return values;
    }

};
