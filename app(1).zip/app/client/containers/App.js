import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { getRoster, updateRosterFlag, activeRoster } from '../actions/roster';
import { getChatMessages, addMessage, incomingMessages, sendAttachment, searchMessages, deleteMessages, setMessages, updateMessage } from '../actions/chat';
import { getChatMessagesByCategory } from '../actions/history';
import { getRooms, getMucInvitation, leaveRoom, updateRoomInfo, updateMucFlag, sendMucInvitation } from '../actions/muc';
import { addNotification, updateFlag, inviteUsers, getNotifications } from '../actions/notification';
import { updateUserStatus, getUserStatus, userLogout } from '../actions/userstatus';

import Main from '../components/Main';

const mapStateToProps = (state) => ({
    rosterData: state.roster,
    clickedRoster: state.roster.active,
    chatData: state.chat,
    roomsData: state.muc.all,
    notificationData: state.notification,
    userInfo: state.userstatus,
    chatAttachments: state.history.attachments,
    chatFavourites: state.history.favourites,
    searchData: state.chat.search,
});

const mapDispatchToProps = {
    getRoster,
    updateRosterFlag,
    activeRoster,
    getChatMessages,
    addMessage,
    incomingMessages,
    sendAttachment,
    getRooms,
    getMucInvitation,
    updateMucFlag,
    getChatMessagesByCategory,
    addNotification,
    leaveRoom,
    updateRoomInfo,
    updateFlag,
    updateUserStatus,
    getUserStatus,
    inviteUsers,
    userLogout,
    searchMessages,
    deleteMessages,
    setMessages,
    updateMessage,
    getNotifications,
    sendMucInvitation
}

export default connect(mapStateToProps, mapDispatchToProps)(Main)
