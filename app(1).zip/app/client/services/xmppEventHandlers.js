/*global me, app, client*/

var _ = require('underscore');
//var async = require('async');
//var crypto = require('crypto');
//var bows = require('bows');
//var uuid = require('node-uuid');
//var HumanModel = require('human-model');
var XMPP = require('stanza.io');
var Contacts = require('../models/contacts');
//var Message = require('../models/message');
//var Call = require('../models/call');


module.exports = function (client, app) {
    var contacts = {};
    client.on('*', function (name, data) {
        if (name === 'raw:incoming') {
            //console.log(data.toString());
        } else if (name === 'raw:outgoing') {
            //console.log(data.toString());
        }
    });

    client.on('session:started', function (jid) {
        //me.jid = jid;

        client.getRoster(function (err, resp) {
            client.sendPresence({
                //status: me.status,
                //caps: client.disco.caps
            });

            if (resp.roster && resp.roster.items && resp.roster.items.length) {
                //app.storage.roster.clear(function () {
                    //me.contacts.reset();
                    //me.rosterVer = resp.roster.ver;                    
                    contacts = Contacts.fliterContacts(contacts, resp.roster.items);
                    //console.log(contacts);
                    //$('#contacts').html('asasasasasasasasaaaaaa');
                //});
            }

            //var caps = client.updateCaps();
            //app.storage.disco.add(caps.ver, caps.discoInfo, function () {
                //client.sendPresence({
                    //status: me.status,
                    //caps: client.disco.caps
                //});
                //client.enableCarbons();
            //});

            //me.mucs.fetch();
        });

        var keepalive;
        keepalive = JSON.parse(localStorage.keepalive || '{}');
        client.enableKeepAlive(keepalive);
    });

    client.on('available', function(data){
        var values = [];
        //var values = {};
        values.push({
            [data.from.bare]:{status:data.type},
        }); 
        
        contacts = Contacts.fliterContacts(contacts, values);
        //console.log(contacts);
        //Contacts.setContacts(values, 'update');

        //console.log(values);
        //console.log(data.type);
        //for(var i=0; i<data.length; i++){
          //  console.log(data.type);
        //}
        //console.log(values);
        //Contacts.setContacts(values);
        //if (resp.roster && resp.roster.items && resp.roster.items.length) {
            //app.storage.roster.clear(function () {
            //me.contacts.reset();
            //me.rosterVer = resp.roster.ver;
            //Contacts.setContacts(resp.roster.items);
            //});
        //}
    });

    

    
};
