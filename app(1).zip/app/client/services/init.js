var StanzaIO = require('stanza.io');

module.exports = {
    launch: function () {
        var self = window.app = this;
        var self = this;
        var config = {
            jid: localStorage.jid,
            password: localStorage.pass,
            transport: 'websocket',
            resource:'asergis',
            wsURL: 'wss://ejabberd.asergiscloud.com:5280/websocket'
        };
        if (!config) {
            window.location = '/login';
        }

        //initialise stanza client
        self.api = window.client = StanzaIO.createClient(config);

        self.api.once('session:started', function () {
            self.sessionStarted = true;

            setInterval(function() {
                client.sendPresence();
                //console.log(localStorage.jid + 'presence');
            }, 60000);
        });
        self.api.connect();
    },
    whenConnected: function (func) {
        if (self.sessionStarted) {
            func();
        } else {
            app.api.once('session:started', func);
        }
    },
    navigate: function (page) {
        var url = (page.charAt(0) === '/') ? page.slice(1) : page;
        app.state.markActive();
        app.history.navigate(url, true);
    }
};
