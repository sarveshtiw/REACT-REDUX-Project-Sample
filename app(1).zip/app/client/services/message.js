var _ = require('underscore');
import axios from 'axios';
import configData from '../data/config';
import { request } from 'graphql-request';

module.exports = {
	getEmailContent: function(key, param){
		switch(key){
			case 'MUC_INVITATION': {
				var data = { 
					'token': localStorage.token,
					'from': configData.email.from,
					'to': param.toUser,
					'subject': param.subject,
					'message':'You have been invited to join the conference by ' + param.from					
				};

				return data;
			}
			case 'CHAT_MENTION': {
				var data = { 
					'token': localStorage.token,
					'from': configData.email.from,
					'to': param.toUser,
					'subject': param.subject,
					'message':'You have new mentions from the Message Centre'
				};

				return data;
			}
		}
	},
    sendNotification: function (reqParams, type) { 
        Object.keys(reqParams || {}).map((keyName, keyIndex) => {	
			var reqData = this.getEmailContent(type, reqParams[keyIndex])		
            axios({
				method: 'POST',
				url: configData.api_url + '/user-send-mail',
				data: reqData,
				headers: { 'content-Type': 'application/json' }
			})
			.then(function (response) {
				var options = {body: reqData.message};
				client.getAttention(reqParams[keyIndex].toUser, options);
                console.log('send', reqParams[keyIndex].toUser, options);
			})
			.catch(function (error) {
				console.log(error);
			});
        });
    },  
    joinChannel: function(conf, nick, opts){
        Object.keys(conf || {}).map((keyName, keyIndex) => { 
			//assign values to new variables 
			var nick = localStorage.name.replace(/[^A-Z0-9]+/ig, '');  
			var roomName = conf[keyIndex].conference.jid.bare;  
			var role =  conf[keyIndex].conference.role ? conf[keyIndex].conference.role : '';    
			var affiliation = conf[keyIndex].conference.affiliation ? conf[keyIndex].conference.affiliation : '';
			var description = conf[keyIndex].conference.description ? conf[keyIndex].conference.description : '';
			
			//for avoiding multi room join error
			client.leaveRoom(roomName, nick);
			client.joinRoom(roomName, nick, {
				status: '',
			});

			/*
			if(affiliation) {
				client.setRoomAffiliation(roomName, localStorage.jid, 
					affiliation, description, function(err, res){
						console.log("setRoomAffiliation", err, res);
				});
			}*/

			//if(role) {
				//client.setRoomRole(roomName, nick, "none", description,
					//function(err, res){
					//console.log("RoomRole", err, res);
				//});

				//client.getRoomMembers(roomName,{items: [{role: 'moderator'}]},function (err,res){
					//console.log('members',err, res);
				//});
			//}
        });
	},
	saveToElastic: function(messagesarr){		
		axios({
			method: 'POST',
			url: configData.api_url + '/save',
			data: { 'token': localStorage.token,
					'indexName': 'asergis',//searchIndex,
					'documentName': configData.document.chat,
					'data': messagesarr
			},
			headers: { 'content-Type': 'application/json' }
		})
		.then(function (response) {	
			return response;	
		})
		.catch(function (error) {
			console.log(error);
		});
	},
	searchPersonalInfo: function(){
		axios({
            method: 'POST',
            url: configData.api_url + '/search',
            data: {
                'token': localStorage.token,
                'indexName': 'asergis',//searchIndex,
                'documentName': configData.document.user,
                'queryString': {
                    "query": {
                        "match_phrase": { 
							"personalinfo.jid": localStorage.jid  
						}
                    },
                }
            },
            headers: { 'content-Type': 'application/json' }
        })
        .then(function (response) {
			if(response.data.data.hits.total > 0){
				//update userinfo in elastic
				return response.data.data.hits.hits;
			}else{
				//insert userinfo

			}
        })
        .catch(function (error) {
            console.log(error);
		});
	},
	updatePersonalInfo: function(data){
		var keyVal = "";
		if(data.personalinfo.displayName || data.personalinfo.fullName) {
			 keyVal = "ctx._source.personalinfo.status='" + data.personalinfo.status + "';ctx._source.personalinfo.showtypes='" + data.personalinfo.showtypes + "';ctx._source.personalinfo.fullName='" + data.personalinfo.fullName + "';ctx._source.personalinfo.displayName='" + data.personalinfo.displayName + "'";
		}else {
			 keyVal = "ctx._source.personalinfo.status='" + data.personalinfo.status + "';ctx._source.personalinfo.showtypes='" + data.personalinfo.showtypes + "'";
		}
		
		axios({
            method: 'POST',
            url: configData.api_url + '/update',
            data: {
                'token': localStorage.token,
                'indexName': 'asergis',//searchIndex,
                'documentName': configData.document.user,
                'queryString': {
					"script":{
						"source":keyVal,
						"lang":"painless"
					},
					"query":{
						"match_phrase":{
							"personalinfo.jid":localStorage.jid
						}
					}
				}
            },
            headers: { 'content-Type': 'application/json' }
        })
        .then(function (response) {
			console.log(response);
			
        })
        .catch(function (error) {
            console.log(error);
		});
	},
	insertPersonalInfo: function(statusArr){
		axios({
            method: 'POST',
            url: configData.api_url + '/save',
            data: {
                'token': localStorage.token,
                'indexName': 'asergis',//searchIndex,
                'documentName': confaxiosigData.document.user,
                'data': statusArr
            },
            headers: { 'content-Type': 'application/json' }
        })
        .then(function (response) {
			console.log(response);
            return statusArr;
        })
        .catch(function (error) {
            console.log(error);
        });
	},
	sendInvitationToUsers(users){
		Object.keys(users || {}).map((keyName, keyIndex) => {
			if(users[keyIndex]){
				const mutation = `mutation{
					createContact(input: {
						uid_ua_user: 1
						title: "MCA_APP"
						fname: "${users[keyIndex].name}"
						lname: "${users[keyIndex].name}"
						email_ids: ["${users[keyIndex].to.trim()}"]
						numbers: ["${Date.now()}"]
						id_service: 2
						group: 0
					})
					{
						details {
							id_contact
						}
						errors {
							key
							message
						}
					}
				}`;
				request(configData.cm_graphql_endpoint, mutation)
					.then(data => {
						if(data.createContact.errors.length == 0) {
						axios({
							method: 'POST',
							url: configData.api_url + '/invite-users',
							data: { 
								'token': localStorage.token,
								'data': {name: users[keyIndex].name, email: users[keyIndex].to.trim()}
							},
							headers: { 'content-Type': 'application/json' }
						})
						.then(function (response) {
							const formData = new FormData();
							formData.append("from", configData.email.from.trim())
							formData.append("to", users[keyIndex].to.trim());
							formData.append("subject", "Invitation to join");
							formData.append("message", "You have been invited to join the chat. Please click the link below to confirm your email.");
					
							axios({
								method: 'POST',
								url: configData.email_host + '/send-mail',
								headers: {
									'token': localStorage.token
								},
								contentType: 'multipart/form-data',
								data: formData
							})
							.then(function (response) {
								console.log('send', users[keyIndex]);
							})
							.catch(function (error) {
								console.log(error);
							});
						})
						.catch(function (error) {
							console.log(error);
						});
					}
				}).catch(err => {
						return err
				}); 
			}				
		});
		/*Object.keys(users || {}).map((keyName, keyIndex) => {
			if(users[keyIndex]){
				axios({
					method: 'POST',
					url: configData.api_url + '/user-send-mail',
					data: { 
						'token': localStorage.token,
						'from': configData.email.from,
						'to': users[keyIndex].trim(),
						'subject':'Invitation to join',
						'message':'You have been invited to join the chat. Please click the link below to confirm your email.'
					},
					headers: { 'content-Type': 'application/json' }
				})
				.then(function (response) {
					console.log('send', users[keyIndex]);
				})
				.catch(function (error) {
					console.log(error);
				});
			}				
        });*/
	},
	isChatMessageExist: function(chatId) {
		axios({
            method: 'POST',
            url: configData.api_url + '/search',
            data: {
                'token': localStorage.token,
                'indexName': 'asergis',
                'documentName': configData.document.chat,
                'queryString': {
                    "query": {
                        "match_phrase": { 
							"id": chatId 
						}
                    },
                }
            },
            headers: { 'content-Type': 'application/json' }
        })
        .then(function (response) {
			if(response.data.data.hits.total > 0){
				//exist in elastic
				return true;
			}else{
				//not exist in elastic
				return false;
			}
        })
        .catch(function (error) {
            console.log(error);
		});
	},
	updateChatInfo: function(data){
		if(data.hasOwnProperty("isFavourite")){
			var value = "ctx._source.id='" + data.id + "';ctx._source.isFavourite=" + data.isFavourite;
		
		}else if(data.hasOwnProperty("isDeleted")){
			var value = "ctx._source.id='" + data.id + "';ctx._source.isDeleted=" + data.isDeleted;
		}

		axios({
            method: 'POST',
            url: configData.api_url + '/update',
            data: {
                'token': localStorage.token,
                'indexName': 'asergis',
                'documentName': configData.document.chat,
                'queryString': {
					"script":{
						"source":value,
						"lang":"painless"
					},
					"query":{
						"match_phrase":{
							"id":data.id
						}
					}
				}
            },
            headers: { 'content-Type': 'application/json' }
        })
        .then(function (response) {
			console.log(response);			
        })
        .catch(function (error) {
            console.log(error);
		});
	},
	sendNickname: function (data) { 			
		axios({
			method: 'POST',
			url: configData.api_url + '/set-nickname',
			data: { 
				'token': localStorage.token,
				'user': data.name,
				'host': data.host,
				'nickname': data.nickname
			},
			headers: { 'content-Type': 'application/json' }
		})
		.then(function (response) {
			console.log('nickname added successfully', response);
		})
		.catch(function (error) {
			console.log(error);
		});
	}
};