let urlParams = new URLSearchParams(window.location.search);
let token_value = urlParams.get('token');
import configData from '../data/config';

import axios from 'axios';
import emailLists from '../data/users';

if (token_value) {
    axios({
        method: 'POST',
        url: configData.api_url + '/login-get-user-info',
        //url: 'http://192.168.1.168:8000/info',
        crossdomain: true,
        data: { 'token': token_value },
        headers: { "Content-Type": "application/json" }
    })
    .then(function (response) {
        var response = response.data;
        Object.keys(emailLists.emails || {}).map((keyName, keyIndex) => {
            if (emailLists.emails[keyIndex].ampLoggedUser === response.data.email) {
                localStorage.jid = emailLists.emails[keyIndex].mcaLoggedUser;
            }
        });
        
        localStorage.pass = '123456';
        localStorage.name = response.data.name;
        localStorage.token = token_value;
    })
    .catch(function (error) {
        //window.location.assign("https://development.asergiscloud.com/login");
        console.log(error);
    });

    /*localStorage.jid = 'sarvesh@asergis.com';
    localStorage.pass = '123456';
    localStorage.name = 'Sarvesh';
    localStorage.token = token_value;*/

}
