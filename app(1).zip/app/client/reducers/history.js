var _ = require('underscore');
import {
    CHAT_ATTACHMENTS,
    CHAT_FAVOURITES
} from '../actions/history'

// reducer
const initialState = { attachments: {}, favourites: {}};

export default (state = initialState, action) => {

    switch (action.type) {

        case 'CHAT_ATTACHMENTS': {
            const messages = {};
            _.each(action.payload.newVal, function(item) {
                var mid = item.id;
                
                if(localStorage.jid == item.from.jid){
                    var jid = (item.from.channel ? item.from.channel : item.to.jid);
                }else{
                    var jid = (item.from.channel ? item.from.channel : item.from.jid);
                }
                
                if(messages.hasOwnProperty(jid)){
                    messages[jid][mid] = item;
                }else{
                    messages[jid] = {};
                    messages[jid][mid] = item;
                }

            });
            var allmessages = Object.assign({}, state, {
                attachments: messages
            });
            return allmessages;
        }

        case 'CHAT_FAVOURITES': {
            const messages = {};
            _.each(action.payload.newVal, function(item) {
                var mid = item.id;
                
                if(localStorage.jid == item.from.jid){
                    var jid = (item.from.channel ? item.from.channel : item.to.jid);
                }else{
                    var jid = (item.from.channel ? item.from.channel : item.from.jid);
                }
                
                if(messages.hasOwnProperty(jid)){
                    messages[jid][mid] = item;
                }else{
                    messages[jid] = {};
                    messages[jid][mid] = item;
                }

            });
            var allmessages = Object.assign({}, state, {
                favourites: messages
            });
            return allmessages;
        }

        default: {
            return state
        }
    }
}
