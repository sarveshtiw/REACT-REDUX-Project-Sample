import { 
    USER_STATUS_UPDATE
} from '../constants';

// reducer
const initialState = { status: {}, showtypes: {} };


export default (state = initialState, action) => {
    switch (action.type) {
        case 'USER_STATUS_UPDATE': {
            var userstatus = { 
                ...state,
                showtypes: action.payload.newVal.showtypes,
                status:action.payload.newVal.status,
                fullName: action.payload.newVal.fullName,
                displayName: action.payload.newVal.displayName
            };
            return userstatus;
        }
        default: {
            return state
        }
    }
}