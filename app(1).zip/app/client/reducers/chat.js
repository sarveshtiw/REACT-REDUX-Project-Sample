var _ = require('underscore');
var moment = require('moment');

import {
    CHAT_HISTORY,
    CHAT_ADD,
    CHAT_REMOVE,
    CHAT_UPDATE,
    CHAT_SEND_ATTACHMENT
} from '../actions/chat'

// reducer
const initialState = { all: {}, search:{}, editmessage:{}};

export default (state = initialState, action) => {

    switch (action.type) {

        case 'CHAT_OUTGOING': {
            const jid = (action.payload.newVal.from.channel ? action.payload.newVal.from.channel : action.payload.newVal.to.jid);
            const mid = action.payload.newVal.id;
            var messages = {
                ...state,
                all: {...state.all,
                    [jid]: {...state.all[jid],
                        [mid]:action.payload.newVal,
                    }
                }
            }
            return messages;
        }
        case 'CHAT_INCOMING': {
            const jid = (action.payload.newVal.from.channel ? action.payload.newVal.from.channel : action.payload.newVal.from.jid);
            const mid = action.payload.newVal.id;
            var messages = {
                ...state,
                all: {...state.all,
                    [jid]: {...state.all[jid],
                        [mid]:action.payload.newVal,
                    }
                }
            }
            return messages;
        }
        case 'CHAT_HISTORY': {            
            if(action.payload.length){
                var messages = state.all; 
            }else{
                var messages = {};
            }
            _.each(action.payload.newVal, function(item) {
                //console.log('@@@@', item);
                var mid = item.id;
                
                if(localStorage.jid == item.from.jid){
                    var jid = (item.from.channel ? item.from.channel : item.to.jid);
                }else{
                    var jid = (item.from.channel ? item.from.channel : item.from.jid);
                }
                
                if(messages.hasOwnProperty(jid)){
                    messages[jid][mid] = item;
                }else{
                    messages[jid] = {};
                    messages[jid][mid] = item;
                }
            });
            
            let allmessages = Object.assign({}, state, {
                all: messages, 
                total:action.payload.total,
                scrollId: action.payload.scrollId,
            });
            
            return Object.assign(...state.all, allmessages);
        }
        case 'CHAT_SEARCH': {
            var messages = Object.assign({}, state, {
                search: action.payload.newVal.map((item, index) => {
                    //if (index === action.index) {
                        //return Object.assign({}, search, {
                            //[item.id]: item
                        //})
                    //}
                    return item;
                })
            })
            console.log('===@@@@==>>>>>>', messages);
            return messages;
        }
        case 'CHAT_REMOVE': {
            let copy = Object.assign({}, state);
            let jid = action.payload.newVal.to.jid;
            let mid = action.payload.newVal.id;
            
            delete copy.all[jid][mid] // shallowly mutating a shallow copy is fine
            return copy;
        }
        case 'CHAT_MSG_UPDATE': {
            var messages = Object.assign({}, state, {
                    editmessage: action.payload.newVal
                })
            return messages;
        }
        case 'CHAT_UPDATE': {
            const jid = (action.payload.newVal.from.channel ? action.payload.newVal.from.channel : action.payload.newVal.to.jid);
            const mid = action.payload.newVal.id;
            var messages = {
                ...state,
                all: {...state.all,
                    [jid]: {...state.all[jid],
                        [mid]:action.payload.newVal,
                    }
                },
                editmessage: {}
            }
            return messages;
        }
        default: {
            return state
        }
    }
}
