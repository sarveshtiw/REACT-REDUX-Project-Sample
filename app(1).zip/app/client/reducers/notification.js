import { 
    NOTIFICATION_ADD,
    NOTIFICATION_STATUS
} from '../constants';

// reducer
const initialState = { all: {}, active: {}, status: 0 };


export default (state = initialState, action) => {

    switch (action.type) {
        case 'NOTIFICATION_HISTORY': {
            var notifications = Object.assign({}, state, {
                all: action.payload.newVal
            });
            return notifications;
        }

        case 'NOTIFICATION_ADD': {
            var notificationid = action.payload.newVal.id;  
            var notification = { 
                ...state,
                all: {...state.all, 
                     [notificationid]: action.payload.newVal
                },
                status:1
            };
            return notification;
        }

        case 'NOTIFICATION_STATUS':{
            if(action.payload.newVal){
                var notificationid = action.payload.newVal.id;            
                var data = Object.assign({}, action.payload.newVal, {
                    status: 0
                });

                var notification = { 
                    ...state,
                    all: {...state.all, 
                        [notificationid]: data
                    },
                    status:0
                };
            }else{
                var notification = Object.assign({}, state, {
                    status: 0
                });
            }    
            return notification;
        }

        default: {
            return state
        }
    }
}