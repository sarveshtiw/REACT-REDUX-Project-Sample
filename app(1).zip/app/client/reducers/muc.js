import {
    LIST_MUC,
    ADD_MUC,
    REMOVE_MUC,
    UPDATE_MUC,
    ACTIVE_MUC,
    GET_INVITATION_MUC,
    SEND_INVITATION_MUC,
    LEAVE_ROOM
} from '../actions/muc'

// reducer
const initialState = { all: {}, active: {} };


export default (state = initialState, action) => {

    switch (action.type) {
        case 'LIST_MUC': {
            var contacts = Object.assign({}, state, {
                all: action.payload.newVal,
                //active: action.payload.newVal[0]
            });
            return contacts;
        }

        case 'ACTIVE_MUC':{
            return Object.assign({}, state, {
                active:action.payload.newVal
            });
        }

        case 'CHAT_INCOMING':{
            var rosters = setNewMessage(action, state);
            return rosters;
        }

        case 'GET_INVITATION_MUC':{
            var muc = {
                ...state,
                all: [...state.all, action.payload.newVal]
            }
            return muc;
        }

        case 'UPDATE_MUC':{
            const value = action.payload.newVal;
            
            var muc = Object.assign({}, state, {
                all: state.all.map((item, index) => {
                    if (item.jid.bare === action.payload.newVal.bare) {
                        return Object.assign({}, item, {
                            ['users']: {...item.users,
                                [value.muc.jid.bare]: {
                                    jid: value.muc.jid, 
                                    showtypes: value.muc.showtypes
                                },
                            }
                        })
                    }
                    return item;
                })
            })
            
            return muc;
        }

        case 'LEAVE_ROOM': {
            var keyIndex = action.payload.newVal;
            let groupLists = Object.assign({}, state.all);
            delete groupLists[keyIndex];
            var newArr = Object.assign({}, state, {
               all:  groupLists});
            return newArr;
        }

        case 'UPDATE_ROOM_INFO': {
            var keyIndex = action.payload.newVal;
            var groupLists = Object.assign({}, state.all);          
            groupLists[keyIndex].description = action.payload.description;
            var newArr = Object.assign({}, state, {
                all:  groupLists});
            return newArr;           
        }

        default: {
            return state
        }
    }
}

function setNewMessage(action, state){
    //get active roster
	var active  = state.active;
    var message = action.payload.newVal
    var rosters = state;
    Object.keys(state.all || {}).map((keyName, keyIndex) => {
        //for chat
        if(message.type == 'groupchat' && (message.from.channel === state.all[keyIndex].jid.bare)){
            if(state.active.hasOwnProperty('jid') && message.from.channel === state.active.jid.bare){
                rosters = {
                    ...state,
                    all: {...state.all,
                        [keyIndex]: {...state.all[keyIndex], 
                            unread: 0
                        }
                    }
                }  
                return false;     
            }else{
                rosters = {
                    ...state,
                    all: {...state.all,
                        [keyIndex]: {...state.all[keyIndex], 
                            unread: state.all[keyIndex].unread + 1
                        }
                    }
                }
                return false;
            }            
        }  
    });
    
    return rosters;
}
