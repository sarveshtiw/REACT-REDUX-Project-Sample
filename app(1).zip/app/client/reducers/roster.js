import {
    LIST_CONTACT,
    ADD_CONTACT,
    REMOVE_CONTACT,
    ACTIVE_CONTACT
  } from '../actions/roster'

  // reducer
const initialState = {all:{}, active:{}};


export default (state = initialState, action) => {

    switch(action.type){
        case 'LIST_CONTACT':{
            var contacts = Object.assign({}, state, {
                all: action.payload.newVal,
                active: action.payload.newVal[0]
            });
            return contacts;
        }
        /*
        case 'ADD_CONTACT':{
            return Object.assign({}, state, action.payload.newVal)
        }

        case 'REMOVE_CONTACT':{
            return Object.assign({}, state, action.payload.newVal)
        }
        */
        case 'UPDATE_CONTACT':{
            var contacts = Object.assign({}, state, {
                all: action.payload.newVal,
                //active: action.payload.newVal[0]
            });
            return contacts;
        }

        case 'ACTIVE_CONTACT':{
            return Object.assign({}, state, {
                active:action.payload.newVal,
                countRoomMembers: action.payload.countRoomMembers ? action.payload.countRoomMembers : 0
            });
        }

        case 'CHAT_INCOMING':{
            var rosters = setNewMessage(action, state);
            return rosters;
        }

        default:{
            return state
        }
    }
}

function setNewMessage(action, state){
    //get active roster
	var active  = state.active;
    var message = action.payload.newVal
    var rosters = state;

    Object.keys(state.all || {}).map((keyName, keyIndex) => {
        //for chat
        if(message.type == 'chat' && (message.from.jid === state.all[keyIndex].jid.bare)){
            if(message.from.jid === state.active.jid.bare){
                rosters = {
                    ...state,
                    all: {...state.all,
                        [keyIndex]: {...state.all[keyIndex],
                            unread: 0
                        }
                    }
                }
                return false;
            }else{
                rosters = {
                    ...state,
                    all: {...state.all,
                        [keyIndex]: {...state.all[keyIndex],
                            unread: state.all[keyIndex].unread + 1
                        }
                    }
                }
                return false;
            }
        }
    });

    return rosters;
}
