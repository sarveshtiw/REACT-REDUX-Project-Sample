import { Router, Route, Link, browserHistory, IndexRoute } from 'react-router';
import React, { Component } from 'react';
import { FormGroup, FormControl, Row, Col } from 'react-bootstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import Twemoji from 'react-twemoji';

import Left from './left';
import Chatmain from './main/MiddleArea';
import PlaceholderHead from './placeholderHead';

import EditProfile from './right/editProfile';
import ConversationDetails from './right/conversationDetails';
import SearchMessage from './right/searchMessages';
import TopSearch from './search';

import ConstantList from './../services/global';
import initapp from './../services/init';
var attachMediaStream = require('attachmediastream');

class Dashboard extends Component {

    constructor(props) {
        super(props);
        this.state = {
            isShow: false,
            addClass1: false,
            addClass2: false,
            addClass3: false,
            searchBox: false
        };
        
        this.setOpen = this.setOpen.bind(this);
        this.infoOpen = this.infoOpen.bind(this);
        this.fav = this.fav.bind(this);        
        this.searchBoxOpen = this.searchBoxOpen.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
    }

    fav() {
        this.setState(function (prevState) {
            return {
                addClass1: !prevState.addClass1,
                searchBox: false
            };
        });
    }    

    infoOpen() {
        this.setState(function (prevState) {
            return {
                addClass2: !prevState.addClass2,
                addClass3: false,
                searchBox: false
            };
        });
    }

    searchBoxOpen() {
        this.setState(function (prevState) {
            return {
                searchBox: false
            };
        });
    }

    setOpen() {
        this.setState(function (prevState) {
            return {
                addClass2: false,
                addClass3: !prevState.addClass3,
                searchBox: false
            };
        });
    }

    handleSearch(e) {
        e.preventDefault();
        this.setState({
            addClass2: false,
            addClass3: false,
            searchBox: true
        });        
        this.props.searchMessages(e.target.searchinput.value);
    }

    componentWillMount() {
        let params = this.props.location.query;

        if (Object.keys(params).length !== 0) {
            if (localStorage.jid == '') {
                return { loaded: false };
            }
            initapp.launch();
            
        } else {
            localStorage.jid = 'khushboo@asergis.com';
            localStorage.pass = '123456';
            localStorage.name = "khushboo@asergis.com";
        }
    }

    componentDidMount() {       
        app.whenConnected(function () {
            console.log('connected');

            //if authentication failed
            client.on('auth:failed', function () {
                window.location = '/login';
            });

            //if client diactiveRostersconnected
            client.on('disconnected', function (err) {
                if (err) {
                    console.error(err);
                }
                if (!app.state.hasConnected) {
                    window.location = '/login';
                }
            });

            client.on('session:end', function (result) {
                console.info('daemon session ended, restarting');
            });

            var keepalive;
            keepalive = JSON.parse(localStorage.keepalive || '{}');
            client.enableKeepAlive(keepalive);

            //get roster updates
            client.on('roster:update', function (iq) {
                var items = iq.roster.items;
                console.log('roster--update', items);
            });

            //get pubsub events
            client.on('pubsub:event', function (msg) {
                console.log('pubsub', msg);
            });
        });
      
        //jingle listners
        client.on('jingle:incoming', function (session) {
            console.log('jingle:incoming', session);
            //if (session.addStream) {
            //    session.addStream(localMedia.localStream);
            //}
            session.accept(); 
            // FIXME: send directed presence if not on roster
        });

        client.on('jingle:outgoing', function (session) {
            console.log('jingle:outgoing', session)
        });
    
        client.on('jingle:terminated', function (session) {
            console.log('jingle:terminated', session)
        });
    
        client.on('jingle:accepted', function (session) {
            console.log('jingle:accepted', session)
        });
    
        client.on('jingle:localstream:added', function (stream) {
            console.log('jingle:localstream:added', session)
        });
    
        client.on('jingle:localstream:removed', function () {
            me.stream = null;
        });
    
        client.on('jingle:remotestream:added', function (session, stream) {
            console.log('jingle:remotestream:added', session, stream);
            attachMediaStream(stream, document.getElementById('remoteVideo'));
        });
    
        client.on('jingle:remotestream:removed', function (session) {
            console.log('jingle:remotestream:removed', session)
        });
    
        client.on('jingle:ringing', function (session) {
            console.log('jingle:ringing', session)
        });
    }

    render() {
        const { clickedRoster } = this.props;
        var arrStatus = { 'chat': 'status online', 'away': 'status away', 'dnd': 'status busy', 'xa': 'status inVisible', 'unavailable': 'status inVisible' };
        var status = clickedRoster && arrStatus.hasOwnProperty(clickedRoster.showtypes) ? arrStatus[clickedRoster.showtypes] : 'status inVisible';
        return (
            <div className='app'>
                <Left
                    rosterData={this.props.rosterData}
                    activeRoster={this.props.activeRoster}
                    getRooms={this.props.getRooms}
                    roomsData={this.props.roomsData}
                    getMucInvitation={this.props.getMucInvitation}
                    getRoster={this.props.getRoster}
                    updateRosterFlag={this.props.updateRosterFlag}
                    clickedRoster={this.props.clickedRoster}
                    addNotification={this.props.addNotification}
                    notificationData={this.props.notificationData}
                    leaveRoom={this.props.leaveRoom}
                    updateRoomInfo={this.props.updateRoomInfo}
                    updateFlag={this.props.updateFlag}
                    updateUserStatus={this.props.updateUserStatus}
                    getUserStatus={this.props.getUserStatus}
                    userInfo={this.props.userInfo}
                    inviteUsers={this.props.inviteUsers}
                    userLogout={this.props.userLogout}
                    updateMucFlag={this.props.updateMucFlag}
                    getNotifications={this.props.getNotifications}
                    sendMucInvitation={this.props.sendMucInvitation}
                />
                <div className="main">
                    <div className="chatHead">
                        {/*<PlaceholderHead/>*/}
                        <div className="d-flex">
                            <Col sm={3} className="left">
                                <div className="userName">
                                    <span className={status}></span>
                                    <p className="uName">{clickedRoster ? clickedRoster.name : ''}</p>
                                </div>
                                {clickedRoster && clickedRoster.hasOwnProperty('group') ?
                                    <div className="userNotify">
                                        <Twemoji options={{ className: 'twemoji',ext:'.png' }}>
                                            <span dangerouslySetInnerHTML={{__html: clickedRoster.status}} />                                            
                                        </Twemoji>
                                    </div>
                                    :
                                    <div className="userNotify">
                                        <span><i className="material-icons">perm_identity</i>
                                            {clickedRoster && clickedRoster.hasOwnProperty('countRoomMembers') ? clickedRoster.countRoomMembers : 0}
                                        </span>
                                    </div>
                                }
                            </Col>
                            <Col sm={6} className="center">
                                <TopSearch 
                                    rosterData={this.props.rosterData}
                                    roomsData={this.props.roomsData}
                                    setInput={this.props.setInput}
                                    handleSearch={this.handleSearch}
                                    setInput={this.setInput}
                                    searchMessages={this.props.searchMessages}
                                />
                            </Col>
                            <ul className="right">
                                <li onClick={this.setOpen} className={!this.state.addClass3 ? "" : "active"}>
                                    <i className="material-icons">settings</i>
                                </li>
                                <li onClick={this.infoOpen} className={!this.state.addClass2 ? "" : "active"}>
                                    <i className="material-icons">error_outline</i>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div className="clientBody">                        
                        <Chatmain
                            clickedRoster={this.props.clickedRoster}
                            getChatMessages={this.props.getChatMessages}
                            addMessage={this.props.addMessage}
                            incomingMessages={this.props.incomingMessages}
                            chatData={this.props.chatData}
                            rosterData={this.props.rosterData}
                            sendNotification={this.props.sendNotification}
                            sendAttachment={this.props.sendAttachment}
                            getChatMessagesByCategory={this.props.getChatMessagesByCategory}
                            deleteMessages={this.props.deleteMessages}
                            setMessages={this.props.setMessages}
                            updateMessage={this.props.updateMessage}
                            notificationData={this.props.notificationData}
                            updateFlag={this.props.updateFlag}
                            userInfo={this.props.userInfo}
                        />
                        {(this.state.addClass2 || this.state.addClass3 || this.state.searchBox) &&
                            <div className="rightSidebar">
                                <Scrollbars className="rightScroll" style={{ height: '100%' }} autoHide autoHeight autoHeightMin={300} >
                                    {((this.state.addClass2 || !this.state.addClass3) && !this.state.searchBox) &&
                                        <ConversationDetails
                                            clickedRoster={this.props.clickedRoster}
                                            getChatMessagesByCategory={this.props.getChatMessagesByCategory}
                                            chatAttachments={this.props.chatAttachments}
                                            chatFavourites={this.props.chatFavourites}
                                            infoOpen={this.infoOpen} />
                                    }
                                    {((!this.state.addClass2 || this.state.addClass3) && !this.state.searchBox) && 
                                        <EditProfile 
                                            setOpen={this.setOpen} 
                                            updateUserStatus={this.props.updateUserStatus}
                                            getUserStatus={this.props.getUserStatus}
                                            userInfo={this.props.userInfo}
                                        />
                                    }
                                    {this.state.searchBox &&
                                        <SearchMessage
                                            searchData={this.props.searchData}
                                            searchBoxOpen={this.searchBoxOpen} />
                                    }
                                </Scrollbars>
                            </div>
                        }
                    </div>
                </div>
            </div>
        )
    }
}

export default Dashboard;
