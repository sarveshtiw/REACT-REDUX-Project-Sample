import React, { Component } from 'react';
import { Row, Col, DropdownButton, MenuItem, Button, Modal, FormGroup, FormControl, ControlLabel, HelpBlock, ListGroup, ListGroupItem } from 'react-bootstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import InviteRow from './inviteRow';

class InviteMembers extends Component {
    constructor(props) {
        super(props);

        this.state = {
            show: false,
            multiple: false,
            single: true,
            inviteMembers: false,
            groupusers:'',
        }

        var id = (+ new Date() + Math.floor(Math.random() * 999999)).toString(36);
        this.state.users = [{
            id: id,
            username: 'username_'+id,
            useremail: 'useremail_'+id,
            ['username_'+id]: '',
            ['useremail_'+id]: ''
        }];
        
        this.showModal = this.showModal.bind(this);
        this.hideModal = this.hideModal.bind(this);
        this.multiple = this.multiple.bind(this);
        this.single = this.single.bind(this);
        this.inviteMembers = this.inviteMembers.bind(this);

        //
        this.handleAddEvent = this.handleAddEvent.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    showModal() {
        this.setState({ show: true });
    };

    hideModal(index) {        
        this.setState({ show: false });
    };

    multiple(prevState) {
        this.setState(function (prevState) {
            return {
                multiple: !prevState.multiple
            };
        });
    };

    inviteMembers() {
        this.setState(function (prevState) {
            return {
                inviteMembers: !prevState.inviteMembers
            };
        });
    }

    single(prevState) {
        this.setState({
            single: true,
            multiple: false
        })
    };

    handleAddEvent(evt) {
        var id = (+ new Date() + Math.floor(Math.random() * 999999)).toString(36);
        var user = {
            id: id,
            username: 'username_'+id,
            useremail: 'useremail_'+id,
            ['username_'+id]:'',
            ['useremail_'+id]:''
        }
        this.state.users.push(user);
        this.setState(this.state.users);
    }

    handleRowDelete(user) {
        var index = this.state.users.indexOf(user);
        this.state.users.splice(index, 1);
        this.setState(this.state.users);
    }

    handleChange(evt) {        
        var item = {
            id: evt.target.id,
            name: evt.target.name,
            value: evt.target.value
        };
        var users = this.state.users.slice();

        var newProducts = users.map(function (user) {
            for (var key in user) {
                if (key == item.name && user.id == item.id) {
                    user[key] = item.value;
                }
            }
            return user;
        });
        this.setState({ users: newProducts });
    }

    getGroupEmails(e){
        //get comma seprated emails
        this.setState({ groupusers: e.target.value });
    }

    handleSubmit(e){
        e.preventDefault();
        if(this.state.groupusers){
            this.props.inviteUsers(this.state.groupusers, true);
        }else{
            this.props.inviteUsers(this.state.users);
        }
    }

    render() {
        var conditionalComponent = this.state.addInput ? <b>Appended text</b> : null;
        var rows = this.state.users.map(function (user) {
            return (
                <InviteRow key={user.id} handleChange={this.handleChange.bind(this)} handleRow={()=>this.handleRowDelete.bind(this)} user={user} />
            );
        }, this);
        return (
            <div className="group-area clearfix">
                <Col sm={12}>
                    <div className="areaHead">Invite Members
                        <Button bsStyle="link" onClick={this.inviteMembers} className="material-icons">add</Button>
                    </div>
                </Col>
                  
                {this.state.inviteMembers &&
                    <div className="myModal inviteMembers">
                        <button type="button" className="myModal-close" onClick={this.inviteMembers}>
                            <i className="material-icons">&#xE888;</i>
                            <span>exit</span>
                        </button>
                        <Scrollbars className="overlayScroll" autoHide autoHeight autoHeightMax={`calc(100vh)`}>
                            <div className="myModal-container">
                                <div className="myModal-content">
                                    
                                    <div className="myModal-header">
                                        <h4 className="myModal-title">Invite Members</h4>
                                    </div>                                     
                                    <div className="myModal-body">
                                        <form className="chatInvite" method="post" name="chatInvite" onSubmit={this.handleSubmit}>
                                            {this.state.single && !this.state.multiple ?
                                                <div>                                                
                                                    {rows}
                                                    <p>
                                                        <a href="javascript:void(0)" className="addAnother" onClick={this.handleAddEvent}><i className="material-icons">add_circle_outline</i> Add another</a> or <a href="#" onClick={this.multiple}>add many at once</a>
                                                    </p>
                                                    <div className="channel_default">
                                                        <label>
                                                            Default Channels
                                                        </label>
                                                        <div className="greigh">
                                                            <p id="default_channels_note" className="">
                                                                New <strong>members</strong> will automatically join <strong>general</strong> and <strong>random</strong>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div className="btn-wrap text-right clearfix">
                                                        <Button type="button" className="cancel" onClick={this.inviteMembers}>Cancel</Button>
                                                        <Button type="submit" className="save">Send Invitations</Button>
                                                    </div>
                                                </div> :
                                                <div>
                                                    <FormGroup controlId="formControlsTextarea">
                                                        <ControlLabel>Enter multiple email addresses</ControlLabel>
                                                        <FormControl componentClass="textarea" placeholder="name@example.com, name1@example.com" value={this.state.groupusers} onChange={this.getGroupEmails.bind(this)} rows="5" />
                                                    </FormGroup>
                                                    <p className="input_note">Please separate multiple addresses with commas. <strong>Keep in mind that we may limit the number of invitations you can send if your workspace currently has a low acceptance rate.</strong> Our Help Center has.</p>
                                                    <div className="btn-wrap pull-right">
                                                        <Button type="button" className="cancel" onClick={this.single}>Cancel</Button>
                                                        <Button type="submit" className="save">Add Invitees</Button>
                                                    </div>
                                                </div>}
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </Scrollbars>
                    </div>}
                <Modal
                    show={this.state.show}
                    onHide={this.hideModal}
                    bsSize="large"
                    dialogClassName="custom-modal"
                    backdrop="static"
                    className="inviteMembers">
                    <Modal.Header closeButton>
                        <Modal.Title>Invite Members</Modal.Title>
                    </Modal.Header>
                    <Modal.Body className>
                    </Modal.Body>
                </Modal>
            </div>
        );
    }
}

export default InviteMembers;
