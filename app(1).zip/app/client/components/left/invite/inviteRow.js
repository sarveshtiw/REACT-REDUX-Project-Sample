import React, { Component } from 'react';
import { Row, Col, DropdownButton, MenuItem, Button, Modal, FormGroup, FormControl, ControlLabel, HelpBlock } from 'react-bootstrap';


function FieldGroup({ id, label, help, ...props }) {
    return (
        <FormGroup controlId={id}>
            <ControlLabel>{label}</ControlLabel>
            <FormControl {...props} />
            {help && <HelpBlock>{help}</HelpBlock>}
        </FormGroup>
    );
}

class InviteRow extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        const {user} = this.props;      
        return (
            <div className="show-grid clearfix" key="0">
                <Col sm={6}>
                    <FieldGroup
                        type="text"
                        label="Email Address"
                        placeholder="name@example.com"
                        id={user.id}
                        name={user.useremail}
                        onChange={this.props.handleChange}
                        value={user.useremailvalue}
                        required
                        email
                    />
                </Col>
                <Col sm={6}>
                    <FieldGroup
                        type="text"
                        label="Full Name"
                        placeholder="Optional"
                        id={user.id}
                        name={user.username}  
                        value={user.usernamevalue}
                        onChange={this.props.handleChange}                                             
                    />
                </Col>
                <Col sm={1}>
                    <FormGroup className="row">
                        <ControlLabel>&nbsp;</ControlLabel>
                        <button type="button" className="form-control material-icons close" onClick={this.props.handleRow(user)}>close</button>
                    </FormGroup>
                </Col>
            </div>
        )
    }
}            

export default InviteRow;