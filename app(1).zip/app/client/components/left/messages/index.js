import React, { Component } from 'react';
import { Col, DropdownButton, MenuItem, Button, Modal } from 'react-bootstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import Twemoji from 'react-twemoji';
var LocalMedia = require('localmedia');
var attachMediaStream = require('attachmediastream');

class DirectMsg extends Component {

    constructor(props) {
        super(props);
        this.state = {
            show: false
        };
        this.showModal = this.showModal.bind(this);
        this.hideModal = this.hideModal.bind(this);
        this.updateChatSection = this.updateChatSection.bind(this);
    }

    showModal() {
        this.setState({ show: true });
    };

    hideModal() {
        this.setState({ show: false });
    };

    updateChatSection(value) {
        //call action and assign this value to reducer
        this.props.activeRoster(value);
    }

    calluser(){
        console.log(client);
        //client.jingle.call('sarvesh@asergis.com/asergis');
        //var sess = client.jingle.createMediaSession('sarvesh@asergis.com/asergis');
        //sess.addStream(stream);
        //sess.start();

       var localMedia = client.localMedia = new LocalMedia();
        
       localMedia.on('localStream', function (stream) {
            attachMediaStream(stream, document.getElementById('localVideo'), {
                mirror: true,
                muted: true
            });
        });

       localMedia.start(null, function (err, stream) {
            var sess = client.jingle.createMediaSession('ravi@asergis.com/asergis');
            sess.addStream(stream);
            sess.start();
        });
    }

    render() {
        const { rosterData, clickedRoster } = this.props;
        var arrStatus = { 'chat': 'status online', 'away': 'status away', 'dnd': 'status busy', 'xa': 'status inVisible' };

        return (
            <div className="directMsg-area clearfix">
                <div id="localVideo"></div>
                <Col sm={12}>
                    <div className="areaHead">Direct Messages
                      <Button bsStyle="link" onClick={this.showModal} className="material-icons">send</Button>
                    </div>
                </Col>
                <ul className="userListing">
                    {Object.keys(rosterData.all || {}).map((keyName, keyIndex) => {
                        let isOnline = rosterData.all[keyName].showtypes ? arrStatus[rosterData.all[keyName].showtypes] : 'status inVisible';
                        let isReadMsg = rosterData.all[keyName].unread == 0 ? '' : 'notification';
                        let activeUser = clickedRoster && clickedRoster.jid.bare == rosterData.all[keyName].jid.bare ? 'active' : '';
                        let liClasses = `${activeUser} ${isReadMsg}`;
                        
                        return (
                            <li className={liClasses} key={keyIndex} onClick={() => this.updateChatSection(rosterData.all[keyName])}>
                                <div className="userIcon">
                                    <span className={isOnline}></span>
                                    {/*<img src="images/alex-parker.png" alt="Alex Parker"/>*/}
                                    {rosterData.all[keyName].name.substr(0, 1).toUpperCase()}
                                </div>
                                <div className="userName">
                                    <p>{rosterData.all[keyName].name ? rosterData.all[keyName].name : rosterData.all[keyName].jid.local}</p>
                                    <Twemoji options={{ className: 'twemoji', ext:'.png' }}>
                                        <span dangerouslySetInnerHTML={{__html: rosterData.all[keyName].status}} />
                                    </Twemoji>
                                </div>
                                {isReadMsg ?
                                    <span className="notify">{rosterData.all[keyName].unread}</span>
                                    : ''
                                }
                            </li>
                        )
                    })}
                </ul>
                <Modal
                    {...this.props}
                    show={this.state.show}
                    onHide={this.hideModal}
                    bsSize="large"
                    dialogClassName="custom-modal"
                    backdrop="static"
                >
                    <Modal.Header closeButton>
                        <Modal.Title>Direct Messages</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <form className="HeadInput">
                            <div className="bootstrap-tagsinput">

                                {Object.keys(rosterData.all || {}).map((keyName, keyIndex) => {
                                    return (
                                        <span key={keyIndex} className="tag label label-info">{rosterData.all[keyName].name.substr(0, 1).toUpperCase()}
                                            <span className="material-icons" data-role="remove">&#xE888;</span>
                                        </span>
                                    )
                                })}

                            </div>
                            <Button className="btn-start">Start</Button>
                            <input type="text" value="" data-role="tagsinput" style={{
                                display: 'none'
                            }} />
                            <div className="conversationHistory">conversation history</div>
                        </form>
                        <Scrollbars className="overlayScroll" autoHide autoHeight 
                            autoHeightMin={300}
                            autoHeightMax={500} >
                            <ul className="userListing">
                                {Object.keys(rosterData.all || {}).map((keyName, keyIndex) => {

                                    return (
                                        <li key={keyIndex} className={rosterData.all[keyName].status == 'available' ? 'online' : 'offline'} key={keyIndex}>
                                            <div className="userIcon">
                                                <span className={rosterData.all[keyName].status == 'available' ? 'online' : 'offline'}></span>
                                                {/*<img src="images/alex-parker.png" alt="Alex Parker"/>*/}
                                                {rosterData.all[keyName].name.substr(0, 1).toUpperCase()}
                                            </div>
                                            <div className="userName">
                                                <p>{rosterData.all[keyName].name}</p>
                                                <span>{rosterData.all[keyName].name.substr(0, 1).toUpperCase()}</span>
                                            </div>
                                        </li>
                                    )
                                })}
                            </ul>
                        </Scrollbars>
                    </Modal.Body>
                </Modal>
            </div>
        );
    }
}

export default DirectMsg;
