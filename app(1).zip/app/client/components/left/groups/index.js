import React, { Component } from 'react';
import { Col, DropdownButton, MenuItem, Button, Modal, FormGroup, FormControl, ControlLabel, HelpBlock } from 'react-bootstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import Toggle from 'react-bootstrap-toggle';
import Select from 'react-select';
import 'react-select/dist/react-select.css';
import Twemoji from 'react-twemoji';
import msgService from './../../../services/message'; 
var _ = require('underscore');

function FieldGroup({ id, label, help, ...props }) {
    return (
        <FormGroup controlId={id}>
            <ControlLabel>{label}</ControlLabel>
            <FormControl {...props} />
            {help && <HelpBlock>{help}</HelpBlock>}
        </FormGroup>
    );
}

class Groupsleft extends Component {

    constructor(props) {
        super(props);
        this.state = {
            show: false,
            mucLists: '', 
            group_name: '', 
            group_purpose: '', 
            value: [], 
            stayOpen: false, 
            inviteMembersGroup: false,
            renameGroup: false
        };
        this.showModal = this.showModal.bind(this);
        this.hideModal = this.hideModal.bind(this);
        this.onToggle = this.onToggle.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleSelectChange = this.handleSelectChange.bind(this);
        this.addNewGroup = this.addNewGroup.bind(this);
        this.updateChatSection = this.updateChatSection.bind(this);
        this.leaveGroup = this.leaveGroup.bind(this);
        this.renameGroup = this.renameGroup.bind(this);
        this.renameGroupPurpose = this.renameGroupPurpose.bind(this);
        this.updateGroupPurpose = this.updateGroupPurpose.bind(this);
        this.inviteMembersGroup = this.inviteMembersGroup.bind(this);
    }

    showModal() {
        this.setState({ show: true });
    };

    hideModal() {
        this.setState({ show: false });
    };

    onToggle() {
        this.setState({
            toggleActive: !this.state.toggleActive
        });
    }

    handleChange(e) {
        this.setState({
            [e.target.name]: e.target.value
        });
    }

    inviteMembersGroup() {
        this.setState(function (prevState) {
            return {
                inviteMembersGroup: !prevState.inviteMembersGroup
            };
        });
    }

    handleSelectChange(value) {
        console.log(value);
        this.setState({ value });
    }

    updateChatSection(value) {
        //call action and assign this value to reducer
        this.props.activeRoster(value);
    }

    //when we create a new group and invite peoples
    addNewGroup(e) {
        e.preventDefault();
        //var group_name = this.state.group_name + '@conference.asergis.com';
        var group_purpose = this.state.group_purpose;
        var contacts = this.state.value.split(',');
        const { sendMucInvitation } = this.props;

        if (contacts) {
            //var groupObj = { reason: group_purpose, room: { bare: group_name, local: this.state.group_name } };
            var data = {name: this.state.group_name, contacts: contacts, purpose: group_purpose};
            sendMucInvitation(data);

            //client.invite(group_name, [{ to: contacts }, { reason: group_purpose }]);
        }
        this.setState({ group_name: '', group_purpose: '', contacts: '', value: '', show: false });
        this.inviteMembersGroup();
    }

    leaveGroup(value) {
        const { leaveRoom, roomsData } = this.props;
        var group_name = roomsData[value].jid.bare;

        if (group_name !== 'undefined') {
            //send 
            var roomlocal = group_name.split('@')
			var message = {
                id: client.nextId(),
                to: group_name,
                from: client.jid.bare,
                type: 'groupchat',
                body: 'left ' + roomlocal[0],
                requestReceipt: true,
                //oobURIs: links
            };
            var msgid = client.sendMessage(message);
            
            client.leaveRoom(group_name, localStorage.name);
            var leaveParams = { room: group_name, jid: localStorage.jid, indexName: value };
            leaveRoom(leaveParams);
        }
    }

    renameGroup(value){
        const { roomsData } = this.props;
        var group_name = roomsData[value].jid.bare;
        var group_purpose = roomsData[value].description;

        if (group_name !== 'undefined') {
            this.setState({ 
                group_name: group_name, 
                group_purpose: group_purpose, 
                keyIndex: value 
            });            
        }
        this.renameGroupPurpose();        
    }

    updateGroupPurpose(e) {
        e.preventDefault();
        var data = { room: this.state.group_name, description: this.state.group_purpose, keyIndex: this.state.keyIndex };
        const { updateRoomInfo, getRooms, roomsData } = this.props;
        updateRoomInfo(data);
        this.renameGroupPurpose();      
    }

    renameGroupPurpose() {
        this.setState(function (prevState) {
            return {
                renameGroup: !prevState.renameGroup
            };
        });
    }

    componentDidMount() {
        const { 
            //getRooms, 
            roomsData, 
            getMucInvitation, 
            //getRoster, 
            updateRosterFlag, 
            activeRoster, 
            leaveRoom,
            updateRoomInfo,
            userInfo,
            updateMucFlag 
        } = this.props;

        app.whenConnected(function () {

            client.on('subscribe', function(data){
                console.log('subscribe' ,data);
            });

            client.on('subscribed', function(data){
                console.log('subscribed' ,data);
            });

            client.on('unavailable', function(data){
                var values = [];
                //console.log('unavailable' ,data);
                if(client.jid.bare !== data.from.bare && data.hasOwnProperty('muc') === 0){
                    values.push({
                        [data.from.bare]: { status: data.type, full: data.from.full },
                    });
                    updateRosterFlag(values);
                }
            });

            //get roster updates
            client.on('roster:update', function (iq) {
                var items = iq.roster.items;
                console.log('roster--update', items);
            });

            //get contacts availability status
            /*            
            client.on('available', function (data) {
                var values = [];
                if(client.jid.bare !== data.from.bare){                    
                    values.push({
                        [data.from.bare]: { status: data.type, full: data.from.full },
                    });
                    console.log('available' ,data);
                    //updateRosterFlag(values);
                }
            });
            */

            //get the members information
            /*client.getRoomMembers("instagram@conference.asergis.com",{ items: [ { affiliation: 'member' } ] },function (res){
                    console.log('members', res);
                }
            );*/

            //muc invitation
            client.on('muc:invite', function (pres) {
                console.log('invitation', pres);
                getMucInvitation(pres);
            });

            //when muc join
            client.on('muc:join', function (data) {
                //console.log('joined MUC', data);
            });

            //when muc leave
            client.on('muc:leave', function (data) {
                //console.log('Leave MUC', data);
            });

            //all muc
            client.on('muc:available', function (data) {
                //console.log('Available MUC', data);
            });

            client.on('muc:unavailable', function (data) {
                //console.log('UnAvailable MUC', data);
            });

            client.on('presence', function (data) {
                //console.log('users presence', data);
            });

            //get disco caps
            client.on('disco:caps', function (pres) {
                var values = [];
                if((client.jid.bare !== pres.from.bare) && (client.jid.bare === pres.to.bare)){                    
                    if(pres.hasOwnProperty('muc')){                        
                        updateMucFlag(pres);
                    }else{
                        values.push({
                            [pres.from.bare]: { 
                                showtypes: pres.show,
                                full: pres.from.full,
                                status: pres.status
                            },
                        });
                        updateRosterFlag(values);
                    }
                }                
            });
        });
    }

    componentDidUpdate(){
        const { 
            getRooms, 
            roomsData
        } = this.props;

    }
    
    render() {
        const { roomsData, rosterData, clickedRoster } = this.props;
        var response = {};
        var opt = [];
        if (rosterData) {
            for (var i = 0, l = rosterData.length; i < l; i++) {
                let res = Object.assign({ 'label': rosterData[i].name, 'value': rosterData[i].jid.bare });
                opt.push(res);
            }
        }
        const options = opt;
        const { value, stayOpen } = this.state;
        return (
            <div className="group-area clearfix">
                <Col sm={12}>
                    <div className="areaHead">Groups
                        <Button bsStyle="link" onClick={this.inviteMembersGroup} className="material-icons">add_circle_outline</Button>
                    </div>
                </Col>
                <ul className="userListing">

                    {Object.keys(roomsData || {}).map((keyName, keyIndex) => {
                        let isReadMsg = roomsData[keyName].unread == 0 ? '' : 'notification';
                        let activeUser = (clickedRoster && rosterData[keyName]) && clickedRoster.jid.bare == roomsData[keyName].jid.bare ? 'active' : '';
                        let liClasses = `${activeUser} ${isReadMsg}`;

                        return (
                            <li className={liClasses} key={keyIndex} onClick={() => this.updateChatSection(roomsData[keyName])}>
                                <div className="userIcon">{roomsData[keyName].name && roomsData[keyName].name.substr(0, 1).toUpperCase()}</div>
                                <div className="userName">
                                    <p>{roomsData[keyName].name}</p>
                                    <span title={roomsData[keyName].description}>{roomsData[keyName].description ? roomsData[keyName].description.substr(0, 15) : ''}</span>
                                </div>
                                {isReadMsg ?
                                    <span className="notify">{roomsData[keyName].unread}</span>
                                    : ''
                                }
                                <DropdownButton noCaret pullRight id="dropdown-btn-menu" bsStyle="link" title="...">
                                    <MenuItem key="1" onClick={() => this.leaveGroup(keyName)}>Leave Group</MenuItem>
                                    <MenuItem key="2" onClick={() => this.renameGroup(keyName)}>Rename Group</MenuItem>
                                </DropdownButton>
                            </li>
                        )
                    })}
                </ul>
                {this.state.inviteMembersGroup &&
                    <div className="myModal inviteMembers">
                        <button type="button" className="myModal-close" onClick={this.inviteMembersGroup}>
                            <i className="material-icons">&#xE888;</i>
                            <span>exit</span>
                        </button>
                        <Scrollbars
                            className="overlayScroll"
                            autoHide
                            autoHeight
                            autoHeightMax={`calc(100vh)`}>
                            <div className="myModal-container">
                                <div className="myModal-content">
                                    <div className="myModal-header">
                                        <h4 className="myModal-title">Group Chat Invitation</h4>
                                    </div>
                                    <div className="myModal-body">
                                        <form className="chatInvite" method="post" onSubmit={this.addNewGroup}>
                                            <Toggle
                                                onClick={this.onToggle}
                                                on={'Private'}
                                                off={'Public'}
                                                size="sm"
                                                width="113px"
                                                height="35px"
                                                offstyle="default"
                                                active={!this.state.toggleActive}
                                            />
                                            <p className="thisGc">
                                                {this.state.toggleActive ? "Anyone in your workspace can view and join this group" : "This group can only be viewed or joined by invite"}
                                            </p>
                                            <FieldGroup
                                                type="text"
                                                label="Group Name"
                                                placeholder="e.g. sales group"
                                                id="group_name" name="group_name" onChange={this.handleChange} value={this.state.group_name} required
                                                help="Names must be lowercase, without spaces or periods, and shorter than 26 characters."
                                            />

                                            <FieldGroup
                                                type="text"
                                                label="Description (optional)"
                                                placeholder=""
                                                id="group_purpose" name="group_purpose" onChange={this.handleChange} value={this.state.group_purpose} required
                                                help="Describe the group by giving a small introduction"
                                            />

                                            <FormGroup>
                                                <ControlLabel>Send Invite to (optional)</ControlLabel>
                                                <Select id="contacts" name="contacts"
                                                    multi
                                                    onChange={this.handleSelectChange}
                                                    options={options}
                                                    placeholder="select (multiple)"
                                                    removeSelected={this.state.removeSelected}
                                                    simpleValue
                                                    value={value}
                                                    closeOnSelect={stayOpen}
                                                />
                                            </FormGroup>
                                            <div className="btn-wrap pull-right">
                                                <Button type="button" className="cancel" onClick={this.inviteMembersGroup}>Cancel</Button>
                                                <Button type="submit" className="save">Create Group</Button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </Scrollbars>
                    </div>}
                    {this.state.renameGroup &&
                    <div className="myModal inviteMembers">
                        <button type="button" className="myModal-close" onClick={this.renameGroupPurpose}>
                            <i className="material-icons">&#xE888;</i>
                            <span>exit</span>
                        </button>
                        <Scrollbars
                            className="overlayScroll"
                            autoHide
                            autoHeight
                            autoHeightMax={`calc(100vh)`}>
                            <div className="myModal-container">
                                <div className="myModal-content">
                                    <div className="myModal-header">
                                        <h4 className="myModal-title">Update Group Chat purpose</h4>
                                    </div>
                                    <div className="myModal-body">
                                        <form className="chatInvite" method="post" onSubmit={this.updateGroupPurpose}>
                                            <FieldGroup
                                                type="text"
                                                label="Description (optional)"
                                                placeholder=""
                                                id="group_purpose" name="group_purpose" onChange={this.handleChange} value={this.state.group_purpose} required help="Describe the group by giving a small introduction"
                                            />

                                            <div className="btn-wrap pull-right">
                                                <Button type="button" className="cancel" onClick={this.renameGroupPurpose}>Cancel</Button>
                                                <Button type="submit" className="save">Update Group purpose</Button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </Scrollbars>
                    </div>}
            </div>
        );
    }
}
export default Groupsleft;
