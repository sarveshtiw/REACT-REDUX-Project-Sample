import React, { Component } from 'react';
import { Row, Col } from 'react-bootstrap';
import { Scrollbars } from 'react-custom-scrollbars';


import PlaceholderLeft from './placeholderLeft';
import Leftheader from './header';
import Searchleft from './search';
import Groupsleft from './groups';
import DirectMsg from './messages';
import InviteMembers from './invite';

class Left extends Component {

    constructor(props) {
        super(props);
        this.state = {
            isShow: false
        };
    }

    componentDidMount() {
        const { getRooms, getRoster, getUserStatus, getNotifications } = this.props;

        app.whenConnected(function () {

            //get contact listing
            client.getRoster(function (err, resp) {
                if (resp.roster && resp.roster.items && resp.roster.items.length) {
                    getRoster(resp.roster.items);
                }

                //get personal info
                getUserStatus();

                //get the rooms information
                getRooms();
            
                //get user notifications
                getNotifications();
            });
        })
    }        

    render() {
        return (            
            Object.keys(this.props.rosterData.all).length == 0 ?
            <div className="leftSidebar"><PlaceholderLeft /></div>
            :
            <div className="leftSidebar">
                <Leftheader
                    addNotification={this.props.addNotification}
                    notificationData={this.props.notificationData}
                    updateFlag={this.props.updateFlag}
                    clickedRoster={this.props.clickedRoster}
                    updateUserStatus={this.props.updateUserStatus}
                    getUserStatus={this.props.getUserStatus}
                    userInfo={this.props.userInfo}
                    userLogout={this.props.userLogout}
                    getNotifications={this.props.getNotifications}
                />
                <div className="logo">
                    <Col sm={12}>
                        <img src='/images/logo.png' alt="Logo" />
                    </Col>
                </div>
                <Scrollbars className="leftScroll"
                    autoHide
                    autoHeight
                    autoHeightMin={300}
                    autoHeightMax={`calc(100vh - 145px)`}
                >
                <Searchleft />
                <Groupsleft
                    clickedRoster={this.props.clickedRoster}
                    rosterData={this.props.rosterData}
                    activeRoster={this.props.activeRoster}
                    getRooms={this.props.getRooms}
                    roomsData={this.props.roomsData}
                    getMucInvitation={this.props.getMucInvitation}
                    getRoster={this.props.getRoster}
                    updateRosterFlag={this.props.updateRosterFlag}
                    leaveRoom={this.props.leaveRoom}
                    updateRoomInfo={this.props.updateRoomInfo}
                    updateMucFlag={this.props.updateMucFlag}
                    sendMucInvitation={this.props.sendMucInvitation}
                />
                <DirectMsg
                    rosterData={this.props.rosterData}
                    activeRoster={this.props.activeRoster}
                    clickedRoster={this.props.clickedRoster} />
                    
                <InviteMembers
                    rosterData={this.props.rosterData}
                    activeRoster={this.props.activeRoster}
                    clickedRoster={this.props.clickedRoster}
                    inviteUsers={this.props.inviteUsers} />
                </Scrollbars>
            </div>
        );
    }
}
export default Left;
