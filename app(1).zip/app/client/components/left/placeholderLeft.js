import React, { Component } from 'react';
import { Row, Col } from 'react-bootstrap';

class PlaceholderLeft extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isShow: false
        };
    }
    render() {
        return (
            <div className="placeHolder-wrapper left">
                <div className="placeHolder-item"></div>
            </div>
        );
    }
}
export default PlaceholderLeft;
