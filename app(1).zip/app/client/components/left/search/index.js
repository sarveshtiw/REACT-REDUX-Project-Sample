import React, { Component } from 'react';
import { Button, ButtonGroup, FormGroup, FormControl, Col } from 'react-bootstrap';

class Leftheader extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isShow: true
        };
        this.handleClick = this.handleClick.bind(this);
    }

    handleClick() {
        this.setState(function (prevState) {
            return { isShow: !prevState.isShow };
        });
    }

    render() {
        return (
            <div className="search-area clearfix">
                <Col sm={12}>
                    <ButtonGroup justified className="btnGroup">
                        <Button href="javascript:void(0)" className={this.state.isShow ? 'active' : ''} onClick={this.handleClick}>ALL MESSAGES</Button>
                        <Button href="javascript:void(0)" className={!this.state.isShow ? 'active' : ''} onClick={this.handleClick}>UNREAD</Button>
                    </ButtonGroup>
                    {/*<form>
            <FormGroup controlId="formBasicText" className="btnGroup">
              <FormControl type="text" placeholder="Search" />
            </FormGroup>
          </form>*/}
                </Col>
            </div>
        );
    }
}

export default Leftheader;