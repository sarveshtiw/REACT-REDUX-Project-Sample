import React, { Component } from 'react';
import { InputGroup, FormControl, FormGroup } from 'react-bootstrap';
import { Picker } from 'emoji-mart';
import Moment from 'moment';
import onClickOutside from 'react-onclickoutside';


class Leftheader extends Component {

    constructor(props) {
        super(props);
        this.state = {
            isShow : false,
            addClass1 : false,
            addClass2 : false,
            notify : false,
            notification : null,
            notificationStatus : 0,
            userquote : '',
            userstatus : ''
        };

        this.notify = this.notify.bind(this);
        this.handleClick = this.handleClick.bind(this);
        this.dropDown = this.dropDown.bind(this);
        this.subDropDown = this.subDropDown.bind(this);
        this.setUserStatus = this.setUserStatus.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.setEmoji = this.setEmoji.bind(this);
        this.handleClickOutside = this.handleClickOutside.bind(this);
        this.logout = this.logout.bind(this);
    }

    //hide popup once clicked outside
    handleClickOutside(evt) {
        // ..handling code goes here...
        this.setState(function (prevState) {
            return { 
                isShow: prevState.isShow ? !prevState.isShow : prevState.isShow,
                notify: prevState.notify ? !prevState.notify : prevState.notify,
                addClass1: prevState.addClass1 ? !prevState.addClass1 : prevState.addClass1,
                addClass2: prevState.addClass2 ? !prevState.addClass2 : prevState.addClass2,
            };
        });
    }

    //toggle popup
    handleClick() {
        this.setState(function (prevState) {
            return { isShow: !prevState.isShow };
        });
    }

    //update notification
    notify() {
        this.setState(function (prevState) {
            return { notify: !prevState.notify };
        });
    }

    //toggle dropdown
    dropDown() {
        this.setState(function (prevState) {
            return { addClass1: !prevState.addClass1 };
        });
    }

    //open/close user status subdropdown
    subDropDown() {
        this.setState(function (prevState) {
            return { addClass2: !prevState.addClass2 };
        });
    }

    componentDidMount() {
        const { addNotification } = this.props;
        app.whenConnected(function () {            

            //get user attention
            client.on('attention', function (info) {
                console.log(info);
                addNotification(info);
            });
        });
    }

    //track props status
    componentWillReceiveProps(nextProps) {
        //check active roster values        
        if (nextProps.notificationData !== this.state.notification) {
            var nLength = nextProps.notificationData && Object.keys(nextProps.notificationData.all).length;
            let msg = nLength ? nextProps.notificationData.all : '';
            this.setState({
                notification: msg,
                notificationStatus: nextProps.notificationData.status
            });
        }

        if(nextProps.userInfo.status !== this.state.userquote){
            this.setState({
                userquote: nextProps.userInfo.status,
                userstatus: nextProps.userInfo.showtypes
            });
        }
    }

    //set user staus
    setUserStatus(e){
        e.preventDefault();
        this.props.updateUserStatus(this.state.userstatus, this.state.userquote);
        
        //Attributes:
        //types: One of: available, unavailable, error, probe, subscribe, subscribed, unsubscribe, and unsubscribed.
        //showtypes: One of: away, chat, dnd, and xa (extended away)
    }

    //track changes in input fields and set values
    handleChange(e, status) {
        if(status){
            this.setState({
                userstatus: status
            });
            this.props.updateUserStatus(status, this.state.userquote);
        }else{
            this.setState({
                userquote: e.target.value
            });
        }
    }

    //user logout
    logout(){
        var logout = this.props.userLogout();
    }

    //set emoji on selection
    setEmoji(emoji){
        this.setState({userquote: this.state.userquote + ' ' + emoji.native})
    }

    render() {
        const {notification, notificationStatus} = this.state;
        const {clickedRoster, userInfo} = this.props;
        const arraStatus = { 'chat': 'status online', 'away': 'status away', 'dnd': 'status busy', 'xa': 'status inVisible' };
        return (
            <div className="user-area">
                <div className="h3 text-left">{clickedRoster ? clickedRoster.group : ''}</div>
                <span className={ arraStatus[this.state.userstatus] }></span>
                <div className="dropdown open btn-group btn-group-link profile-menu">
                    <button id="dropdown-btn-menu" aria-haspopup="true" aria-expanded="false" type="button" className="userMenu dropdown-toggle btn btn-link" onClick={this.dropDown}>
                    {localStorage.name}
                        <span className="caret"></span>
                    </button>
                    {this.state.addClass1 &&
                        <ul role="menu" className="dropdown-menu" aria-labelledby="dropdown-btn-menu">
                            <li role="presentation" className="creatApp">
                                <a role="menuitem" tabIndex="-1" href="#">Open Message Centre App <i className="material-icons">call_made</i></a>
                            </li>
                            <li role="presentation" className="profile">
                                <a role="menuitem" tabIndex="-1" href="#">
                                    <img src="images/pp.png" className="img-rounded" alt="Profile" />
                                    {localStorage.name}</a>
                            </li>
                            <li role="presentation" className="status dropdown-submenu">
                                <a role="menuitem" tabIndex="-1" onClick={this.subDropDown}>Set a status <span className="caret"></span></a>
                                <form name="statusform" method="post" onSubmit={this.setUserStatus} className={this.state.addClass2 ? 'dropdown-menu block' : 'dropdown-menu'}>
                                {this.state.addClass2 && <ul className="">
                                    <li role="presentation" className="">
                                        <FormGroup>
                                            <InputGroup>
                                                <InputGroup.Addon onClick={this.handleClick}><span className="icon-emojis"></span></InputGroup.Addon>
                                                <FormControl type="text" name="userquote" placeholder="enter your status" 
                                                value={this.state.userquote} onChange={this.handleChange} />
                                            </InputGroup>
                                        </FormGroup>
                                    </li>
                                    <li role="presentation" className="divider"></li>
                                    <li className="statusIn online"><a tabIndex="-1" href="#" onClick={() => this.handleChange('', 'chat')}>Online</a></li>
                                    <li className="statusIn away"><a tabIndex="-1" href="#" onClick={() => this.handleChange('', 'away')}>Away</a></li>
                                    <li className="statusIn busy"><a tabIndex="-1" href="#" onClick={() => this.handleChange('', 'dnd')}>Busy</a></li>
                                    <li className="statusIn inVisible"><a tabIndex="-1" href="#" onClick={() => this.handleChange('', 'xa')}>Invisible</a></li>
                                    {this.state.isShow && <Picker style={{ position: 'absolute', top: '65px', left: '20px' }} onClick={this.setEmoji} title="" autoFocus="true" />}
                                </ul>}
                              </form>                                
                            </li>
                            <li role="presentation" className="">
                                <a role="menuitem" tabIndex="-1" href="#">Edit Profile</a>
                            </li>
                            <li role="presentation" className="">
                                <a role="menuitem" tabIndex="-1" href="#">Preferences</a>
                            </li>
                            <li role="presentation" className="">
                                <a role="menuitem" tabIndex="-1" href="#">Notification settings</a>
                            </li>
                            <li role="presentation" className="">
                                <a role="menuitem" tabIndex="-1" href="#">Help &amp; support</a>
                            </li>
                            <li role="presentation" className="signOut">
                              <a role="menuitem" tabIndex="-1" href="#" onClick={() => this.logout()}>Sign out</a>
                            </li>
                        </ul>
                    }
                </div>
                <div className="dropdown open btn-group btn-group-link notify-menu">
                    <button
                        id="dropdown-btn-menu"
                        type="button" aria-haspopup="true"
                        aria-expanded="false"
                        className={this.state.notify || notificationStatus ? "material-icons notification btn btn-link active" : "material-icons notification btn btn-link"}
                        onClick={this.notify} >
                        {this.state.notify || notificationStatus ? "notifications_active" : "notifications"}
                    </button>
                    {this.state.notify &&
                        <ul role="menu" className="dropdown-menu" aria-labelledby="dropdown-btn-menu">
                            {Object.keys(notification || {}).map((keyName, keyIndex) => {
                                return (
                                    <li role="presentation" className="" key={keyIndex}>
                                        <a href="/">
                                            <p>{notification[keyName].body}</p>
                                            <p className="time">{Moment(notification[keyName].time).format('hh:mm A')}</p>
                                        </a>
                                    </li>   
                                )                                                        
                            })}
                        </ul>
                    }    
                </div>
            </div>
        );
    }
}

export default onClickOutside(Leftheader);
