import React, { Component } from 'react';
import Test from './Test';

class Welcome extends React.Component {

    constructor(props) {
      super(props);
      this.state = {"test": 0, "count": 0};
      this.handleClick = this.handleClick.bind(this);
      this.handle = this.handle.bind(this);
    }

    handleClick(){
      this.setState({
        "test": this.state.test + 1
      });
      //console.log("state",this.state);
    }

    handle(){
      return this.state;
    }

    render() {
       return(
          <div>{this.state.test}
            <center><h1> Welcome to Message centre application </h1></center>
            <button onClick={this.handleClick}>Click here</button>
            <Test handle={this.handle()} />
          </div>
       )
    }
}

export default Welcome;
