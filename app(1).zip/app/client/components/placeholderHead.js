import React, { Component } from 'react';
import { Row, Col } from 'react-bootstrap';

class PlaceholderHead extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isShow: false
        };
    }
    render() {
        return (
          <div className="placeHolder-wrapper head">
            <div className="placeHolder-item"></div>
          </div>           
        );
    }
}
export default PlaceholderHead;
