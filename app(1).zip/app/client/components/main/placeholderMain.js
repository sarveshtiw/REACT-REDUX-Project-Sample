import React, { Component } from 'react';
import { Row, Col } from 'react-bootstrap';

class PlaceholderMain extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isShow: false
        };
    }
    render() {
        return (
            <div className="placeHolder-wrapper main">
                <div className="welcomeMsg">
                    <div className="loader loader_m">
                        <svg className="loader loader_fast" viewBox="0 0 100 100">
                            <circle className="loader_bg" cx="50%" cy="50%" r="35"></circle>
                            <circle className="loader_path loader_blue" cx="50%" cy="50%" r="35"></circle>
                        </svg>
                        <svg className="loader loader_tail loader_fast" viewBox="0 0 100 100">
                            <circle className="loader_path loader_blue" cx="50%" cy="50%" r="35"></circle>
                        </svg>
                    </div>
                    <p>Loading..</p>
                </div>
            </div>
        );
    }
}
export default PlaceholderMain;
