import React, { Component } from 'react';
import { Row, Col, Button, ButtonGroup, ButtonToolbar } from 'react-bootstrap';
import { Scrollbars } from 'react-custom-scrollbars';
//import { Picker } from 'emoji-mart';
import { Emoji } from 'emoji-mart';
import Message from './Message';
import axios from 'axios';
import messagefilter from '../../../models/messagefilter';
import NotificationBox from '../chatSection/NotificationBox';
import Dropzone from 'react-dropzone';

class ChatMain extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isShow: false,
            addClass1: false,
            addClass2: false,
            addClass3: false,
            clickedRoster: null,
            //message: '',
            rosterValues: '',
            notificationUsers: null,
            files: [],
            disabled: true,

            accept: '',
            dropzoneActive: false,
            requestSent: false,
            datalength: 0,
            data: {all:{}}
        };

        this.setOpen = this.setOpen.bind(this);
        this.infoOpen = this.infoOpen.bind(this);     
        this.deleteMessage = this.deleteMessage.bind(this);   
        
        //scrolling
        this.handleScroll = this.handleScroll.bind(this);
        this.querySearchResult = this.querySearchResult.bind(this);
    }

    onDragEnter() {
        this.setState({
            dropzoneActive: true
        });
    }
    
    onDragLeave() {
        this.setState({
            dropzoneActive: false
        });
    }

    //get dropped files
    onDrop(acceptedFiles) {
        this.setState({
            dropzoneActive: false
        });

        acceptedFiles.forEach(file => {
            
            var messageArr = {
                id: client.nextId(),
                to: this.props.clickedRoster.jid.bare,
                toname: this.props.clickedRoster.name ? this.props.clickedRoster.name : '',
                from: client.jid.bare,
                fromname: this.props.userInfo.displayName,
                type: this.props.clickedRoster.hasOwnProperty('autoJoin') ? 'groupchat' : 'chat',
                requestReceipt: true,
                chatState: 'active'
            };
            console.log(messageArr);
            this.props.sendAttachment(messageArr, file);
            /*
            const reader = new FileReader();
            reader.onload = () => {
                const fileAsBinaryString = reader.result;
                // do whatever you want with the file content
                console.log('------>>>>', fileAsBinaryString);
            };
            reader.onabort = () => console.log('file reading was aborted');
            reader.onerror = () => console.log('file reading has failed');
    
            reader.readAsBinaryString(file);
            */
        });
    }    

    //toggle div elements
    infoOpen() {
        this.setState(function (prevState) {
            return {
                addClass2: !prevState.addClass2,
                addClass3: prevState.addClass3
            };
        });
    }

    //toggle div elements
    setOpen() {
        this.setState(function (prevState) {
            return {
                addClass2: prevState.addClass2,
                addClass3: !prevState.addClass3
            };
        });
    }

    //delete message
    deleteMessage(chatArray) {
        var conf = confirm('Are you sure you want to delete this message? This cannot be undone.');
        if(conf){
            this.props.deleteMessages(chatArray);
        }
    }    

    //load default listners
    componentDidMount() {
        const { incomingMessages, sendAttachment } = this.props;

        app.whenConnected(function () {
            //listners for getting chat messages
            client.on('chat', function (msg) {
                console.log('onemsg', msg);
                //read only one to one chat messages
                if (msg.type === 'chat') {
                    //console.log('one2onemsg', msg);
                    incomingMessages(msg);
                }
            });

            //listners for getting groupchat messages
            client.on('groupchat', function (msg) {
                console.log('groupmsg', msg);

                if (msg.from.resource !== localStorage.name) {
                    incomingMessages(msg);
                }
            });

            //get different states
            client.on('chatState', function (info) {
                //console.log('chatState', info);
            });

            //get message
            client.on('message', function (info) {
                //console.log('message notification', info);
            });

            //get message
            client.on('replace', function (info) {
                console.log('message replace', info);
            });            
        }); 
    }

    querySearchResult() {
        let length = Object.keys(this.props.chatData.all[this.props.clickedRoster.jid.bare]).length;
        //console.log('________', this.state.requestSent,  this.props.chatData);
        if(length < this.props.chatData.total){
            this.setState({
                datalength: length,
                requestSent: true
            },()=>{
                this.props.getChatMessages(this.state.clickedRoster, this.state.datalength, this.props.chatData.scrollId);
            });
        }        
    }

    handleScroll(event) {
        if (event.scrollTop <= 0) {
            this.querySearchResult();
        }
    }

    componentDidMount() {
        //this.handleScroll();
    }

    componentDidUpdate() {
        //this.handleScroll();
    }

    //listen props changes
    componentWillReceiveProps(nextProps) {
        let datalength = 0;
		//check active roster values
		if (nextProps.clickedRoster !== this.state.clickedRoster) {
            this.setState({
                clickedRoster: nextProps.clickedRoster,
                datalength: 0,
            },() => {
                this.props.getChatMessages(nextProps.clickedRoster, this.state.datalength);
            })
        }

        //when a new message arrived load chat scroller
        if(nextProps.chatData.all !== this.state.data.all){

            this.setState({
                requestSent: false,
                data: {all: nextProps.chatData.all}
            })
            setTimeout(function() {
                this.scrollComponent.scrollToBottom();
            }.bind(this), 0);
        }        
    }

    render() {
        const { rosterValues, accept, files, dropzoneActive } = this.state
		const { clickedRoster, chatData } = this.props;
		var sender = Object.keys(clickedRoster).length ? clickedRoster.jid.bare : '';
        var chatArray = chatData.all.hasOwnProperty(sender) ? chatData.all[sender] : {};
        var dateArr = [];
        const overlayStyle = {
            position: 'absolute', top: 0, right: 0, bottom: 0, left: 0, padding: '2.5em 0', 
            background: 'rgba(0,0,0,0.6)', textAlign: 'center', color: '#fff', zIndex: 555
        };
        
        return (
          <div className="ChatMain">
            <Dropzone onDrop={this.onDrop.bind(this)} disableClick style={{position: "relative", height: '100%'}} 
                onDragEnter={this.onDragEnter.bind(this)} multiple={false}
                onDragLeave={this.onDragLeave.bind(this)} >  
                { dropzoneActive && <div style={overlayStyle}>Drop file...</div> }
                <Scrollbars autoHide autoHeight 
                autoHeightMin={0} 
                autoHeightMax={`calc(100vh - 160px)`} 
                ref={c => { this.scrollComponent = c }} 
                onScrollFrame={this.handleScroll} >

                    <Col sm={12} className="msgArea">
                    {Object.keys(chatArray || {}).slice(0).reverse().map((keyName, keyIndex) => {
                        var chat = chatArray.hasOwnProperty(keyName) ? chatArray[keyName] : '';                        
                        var date = messagefilter.setDataFormat(chatArray[keyName].createdOn, dateArr);
                                            
                        return(
                            <Message chatArray={chat} key={keyIndex} dateObj={date}
                            clickedRoster={clickedRoster} 
                            getChatMessagesByCategory={this.props.getChatMessagesByCategory}
                            deleteMessage={this.deleteMessage} 
                            setMessages={this.props.setMessages} />
                        )
                    })}
                    </Col>
                </Scrollbars>
            </Dropzone>    
            <NotificationBox
            notificationData={this.props.notificationData}
            updateFlag={this.props.updateFlag} />
          </div>
        );
    }
}

export default ChatMain;
