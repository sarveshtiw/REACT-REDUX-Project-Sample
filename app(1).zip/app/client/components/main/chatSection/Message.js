import React, { Component } from 'react';
import { Button, FormGroup, FormControl, Col, Row, ButtonGroup, ButtonToolbar } from 'react-bootstrap';
import axios from 'axios';
import configData from '../../../data/config';
import messagefilter from '../../../models/messagefilter';
import msgService from '../../../services/message';
import Twemoji from 'react-twemoji';

class Message extends Component {
    constructor(props) {
        super(props);
        this.state = {
            favClass1: false,
            customDropShow: false,
            return_url: '',
            url_meta_info: '',
            editMode:false,
        };
        this.fav = this.fav.bind(this);
        this.customDrop = this.customDrop.bind(this);
        this.editMessage = this.editMessage.bind(this);   
    }

    customDrop() {
        this.setState(function (prevState) {
            return { customDropShow: !prevState.customDropShow };
        });
    }

    fav(e) {
        const { clickedRoster, getChatMessagesByCategory } = this.props;
        let data = { isFavourite: false, jid: { bare: clickedRoster.jid.full } };
        getChatMessagesByCategory(data);

        msgService.isChatMessageExist(e.id);
        msgService.updateChatInfo({ id: e.id, isFavourite: !this.state.favClass1 });
        this.setState(function (prevState) {
            return { favClass1: !prevState.favClass1 };
        });
    }

    componentDidMount() {
        const { clickedRoster, getChatMessagesByCategory } = this.props;
        let data = { isFavourite: false, jid: { bare: clickedRoster.jid.full } };
        getChatMessagesByCategory(data);
    }

    componentWillMount() {
        var self = this;
        const { chatArray } = this.props;
        var chatbody = chatArray.body;
        var regexHttp = /(http|https):\/\/(\w+:{0,1}\w*)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%!\-\/]))?/;

        if (chatArray.hasOwnProperty("isAttachment") && chatArray.isAttachment === true) {
            axios({
                method: 'GET',
                url: configData.api_minio + '/file-get/?file=' + chatbody + "&asergisPopId=india",
                headers: {
                    'token': localStorage.token
                }
            }).then(function (response) {
                self.setState({
                    return_url: response.data.data.url
                });
            })
            .catch((error) => {
                console.log(error);
            });
        }

        if (regexHttp.test(chatArray.body)) {
            axios({
                method: 'POST',
                url: configData.api_url + '/get-url-meta-info',
                headers: {
                    'token': localStorage.token
                },
                data: { url: chatArray.body },
                json: true
            }).then(function (response) {
                self.setState({
                    url_meta_info: response.data
                });
            })
            .catch((error) => {
                console.log(error);
            });
        }
    }

    componentWillUnmount() {
        var self = this;
        self.setState({
            return_url: ''
        });
    }

    editMessage(chatArray){
        this.setState(function (prevState) {
            return { editMode: !prevState.editMode };
        },
        ()=>{
            if(this.state.editMode){
                this.props.setMessages(chatArray);
            }else{
                this.props.setMessages();
            }
        });
    }

    render() {
        const { chatArray, dateObj } = this.props;
        var isAttachment = false;
        var isFavourite = false;
        var isStar = false;
        let mymsg = (chatArray && chatArray.from.jid === localStorage.jid ? 'next' : '');
        if (chatArray.hasOwnProperty("isAttachment") && chatArray.isAttachment == true) {
            isAttachment = true;
        }
        if (chatArray.hasOwnProperty("isFavourite") && chatArray.isFavourite == true) {
            isFavourite = true;
        }
        isStar = this.state.favClass1 ? this.state.favClass1 : isFavourite;
        
        //for attachment block
        const url_meta_info = this.state.url_meta_info;
        var ogUrl = '';
        if (url_meta_info && url_meta_info.hasOwnProperty("data")) {
            var ogUrl = (url_meta_info && url_meta_info.data.hasOwnProperty("ogImage") ? url_meta_info.data.ogImage.url : '');
        }
        var body = messagefilter.setChatBodyFormat(chatArray, this.state.return_url);

        return (
            <div id={chatArray.id} className="mt-sm">
                {dateObj.timeheader ?
                    <div className="msgAlert row" ><span>{dateObj.msgtime}</span></div>
                    : ''
                }
                <div className={`userChat ${mymsg}`} >
                    <div className="userPic-time">
                        <span className="ppPic">
                            {chatArray.from.jid.substr(0, 1).toUpperCase()}
                        </span>
                        <small>{dateObj.shorttime}</small>
                    </div>
                    <div className="userMsg">
                        <h3>{chatArray.from.name}</h3>
                        {
                            isAttachment ?
                                <div className='userMsg' dangerouslySetInnerHTML={{ __html: body }}></div>
                                :
                                <Twemoji options={{ className: 'twemoji', ext: '.png' }}>
                                    <div className="userMsgIn" id={'inEdit_'+chatArray.id} dangerouslySetInnerHTML={{ __html: body }}></div>
                                </Twemoji>
                        }

                        <ButtonToolbar className={!isStar ? "msgToolbar" : "msgToolbar d-inline"}>
                            <ButtonGroup bsSize="small">
                                <Button onClick={(e) => this.fav(chatArray, e)} className={!isStar ? "" : "active d-inline-color"}>
                                    <i className="material-icons">star</i>
                                </Button>
                                {mymsg && <Button >
                                    <i className="material-icons" onClick={() => this.props.deleteMessage(chatArray)}>delete</i>
                                </Button>}
                                {mymsg && <Button className={this.state.editMode ? "active d-inline-color" : ''}>
                                    <i className="material-icons"  onClick={() => this.editMessage(chatArray)}>edit</i>
                                </Button>}
                                {/*
                                <Button onClick={this.customDrop} style={{ 'borderTopRightRadius': '3px', 'borderBottomRightRadius': '3px' }}>
                                    <i className="material-icons">more_horiz</i>
                                </Button>
                                <div className="dropdown open customDrop clearfix">
                                    <ul role="menu" className="dropdown-menu" aria-labelledby="bg-vertical-dropdown-3">
                                        <li role="presentation" className="">
                                            <a role="menuitem" tabIndex="-1" href="#">Dropdown link</a>
                                        </li>
                                        <li role="presentation" className="">
                                            <a role="menuitem" tabIndex="-1" href="#">Dropdown link</a>
                                        </li>
                                    </ul>
                                </div>
                                */}
                            </ButtonGroup>
                        </ButtonToolbar>
                        {ogUrl ?
                            <blockquote className="ogTagUrl">
                                <p>
                                    <a href={url_meta_info ? url_meta_info.data.ogUrl : ''} target="_blank">
                                        {url_meta_info ? url_meta_info.data.ogSiteName : ''}
                                    </a>
                                </p>
                                <p>{url_meta_info ? url_meta_info.data.ogTitle : ''}</p>
                                <p>{url_meta_info ? url_meta_info.data.ogDescription : ''}</p>
                                <p>
                                    <a href={url_meta_info ? ogUrl : ''} target="_blank">
                                        <img src={url_meta_info ? ogUrl : ''} />
                                    </a>
                                </p>
                                {/*
                video
                <div className="row">
                    <div className="col-sm-6">
                    <div className="embed-responsive embed-responsive-16by9">
                        <iframe src="https://www.youtube.com/embed/yqS-Y9_pxKE" frameborder="0" allowfullscreen className="embed-responsive-item "></iframe>
                    </div>                              
                    </div>
                </div> */}
                            </blockquote>
                            // <div className="userMsg2" 
                            //     style={{"paddingTop":"10px", "width": "100%", "paddingLeft":"30px", 
                            //     "borderLeft": "2px solid #ccc",
                            //     "marginBottom": "10px"
                            //     }}>

                            //     <div className='userMsgIn1'>
                            //         <p>
                            //             <a href={url_meta_info ? url_meta_info.data.ogUrl : ''} target="_blank">
                            //                 {url_meta_info ? url_meta_info.data.ogSiteName : ''}
                            //             </a>
                            //         </p>
                            //         <p>{url_meta_info ? url_meta_info.data.ogTitle : ''}</p>
                            //         <p>{url_meta_info ? url_meta_info.data.ogDescription : ''}</p>
                            //         <p>
                            //             <a href={url_meta_info ? ogUrl : ''} target="_blank">
                            //                 <img src={url_meta_info ? ogUrl : ''} />
                            //             </a>
                            //         </p>
                            //     </div> 
                            // </div>   
                            : ''
                        }

                    </div>
                </div>
            </div>
        );
    }
}

export default Message;