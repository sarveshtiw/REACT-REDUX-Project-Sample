import React, { Component } from 'react';
import messageFilter from '../../../models/messagefilter';
import moment from 'moment';

class NotificationBox extends Component {

    constructor(props) {
        super(props);
        this.state = {
            notification: {all:[], active:[]}
        };
        this.updateNotification = this.updateNotification.bind(this);
        this.cancelNotifications= this.cancelNotifications.bind(this);
    }

    //track changes in to props and update state
    componentWillReceiveProps(nextProps) {
        //check active roster values  
        if (nextProps.notificationData !== this.state.notification.all) {            
            var message = messageFilter.activeNotifications(nextProps.notificationData);
            this.setState({notification:{
                all: nextProps.notificationData,
                active: message
            }},
                ()=>{
                    this.updateNotification();
                }
            );
        }
    }

    //update notification status when read
    updateNotification(){
        var that = this;
        if(Object.values(this.state.notification.active).length && this.state.notification.active){
            var activeArr = that.state.notification.active;
            setTimeout(function(){ 
                that.props.updateFlag(activeArr[Object.keys(activeArr)[0]]);
            }, 5000);
        }    
    }

    //update all active notifications
    cancelNotifications(){
        this.props.updateFlag();
        this.setState({notification:{active:[]}});
    }

    render(){
        const { notification } = this.state;
        
        return(  
            Object.keys(this.state.notification.active).length ?           
            <div className="notificationArea">
                <span className="material-icons cancel" onClick={this.cancelNotifications}>cancel</span>
                {Object.keys(notification.active || {}).map((keyName, keyIndex) => {
                    return (
                        <div className="notificationBox" key={keyIndex}>
                            <div className="userPic">
                                <div className="userIcon">{notification.active[keyName].from.local.substr(0, 1).toUpperCase()}</div>
                            </div>
                            <div className="userDesec">
                                <h3 className="heading">{notification.active[keyName].from.local} <span className="time">{moment(notification.active[keyName].createdOn).format("h:mm a")}</span></h3>
                                <p className="helloJennyPlease">
                                    {notification.active[keyName].body}
                                </p>
                            </div>
                        </div>
                    )
                })}    
            </div>
            :
            <div></div>
        )
    }
}

export default NotificationBox;