import React, { Component } from 'react';
import { Col } from 'react-bootstrap';
import ChatMain from './chatSection';
import ChatInsert from './chatInsert';
import PlaceholderMain from './placeholderMain';
import GroupOverlay from './groupOverlay.js';


class MiddleArea extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className="colMessages">
                {
                    Object.keys(this.props.chatData.all).length == 0 ?
                        <PlaceholderMain  />
                    :''
                }
                {/*<GroupOverlay />*/}
                <ChatMain
                chatData={this.props.chatData}
                clickedRoster={this.props.clickedRoster}
                getChatMessages={this.props.getChatMessages}
                incomingMessages={this.props.incomingMessages}
                getChatMessagesByCategory={this.props.getChatMessagesByCategory}
                deleteMessages={this.props.deleteMessages}
                setMessages={this.props.setMessages}
                notificationData={this.props.notificationData}
                updateFlag={this.props.updateFlag}
                sendAttachment={this.props.sendAttachment}
                userInfo={this.props.userInfo}   />

                <ChatInsert
                clickedRoster={this.props.clickedRoster}
                sendNotification={this.props.sendNotification}
                sendAttachment={this.props.sendAttachment}
                addMessage={this.props.addMessage}
                rosterData={this.props.rosterData}
                chatData={this.props.chatData}
                updateMessage={this.props.updateMessage}
                userInfo={this.props.userInfo} />
            </div>
        );
    }
}

export default MiddleArea;
