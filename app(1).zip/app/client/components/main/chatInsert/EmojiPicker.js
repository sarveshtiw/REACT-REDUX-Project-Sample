import React, { Component } from 'react';
import { Button, FormGroup, FormControl, Col } from 'react-bootstrap';
import { Picker } from 'emoji-mart';
import onClickOutside from 'react-onclickoutside';

class EmojiPicker extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            isShow: false, 
        };

        this.handleClickOutside = this.handleClickOutside.bind(this);
        this.handleClick = this.handleClick.bind(this);        
    }

    handleClick() {
        this.setState(function (prevState) {
            return { isShow: !prevState.isShow };
        });
    }

    handleClickOutside(evt) {
        // ..handling code goes here...
        this.setState(function (prevState) {
            return { 
                isShow: prevState.isShow ? !prevState.isShow : prevState.isShow,
            };
        });
    }

    render() {
        return (
            <div>
                {this.state.isShow && 
                    <Picker style={{ position: 'absolute', bottom: '68px', right: '40px' }} 
                    onClick={this.props.setEmoji} title="" autoFocus="true" />
                }
                <Button type="button" className="emojis" onClick={this.handleClick}>
                    <img src="images/emojis.png" alt="" />
                </Button>
            </div>
        );
    }
}

export default onClickOutside(EmojiPicker);