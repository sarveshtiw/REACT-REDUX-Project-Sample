import React, { Component } from 'react';
import { Button, FormGroup, FormControl, Col } from 'react-bootstrap';
import { Picker } from 'emoji-mart';
import { MentionsInput, Mention } from 'react-mentions';
import EmojiPicker from './EmojiPicker';
var _ = require('underscore');

class ChatInsert extends Component {

    constructor(props) {
        super(props);
        this.state = { 
            message: '', 
            notificationUsers: [],
            oldMessage: '' 
        };

        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.fileOnChange = this.fileOnChange.bind(this);
        this.getUsersForNotification = this.getUsersForNotification.bind(this);
        this.setEmoji = this.setEmoji.bind(this);
        this.handleTextareaKeypress = this.handleTextareaKeypress.bind(this);
    }

    //file upload feature once user has selected file
    fileOnChange(e) {
        e.preventDefault();        
        var messageArr = {
                id: client.nextId(),
                to: this.props.clickedRoster.jid.bare,
                toname: this.props.clickedRoster.name ? this.props.clickedRoster.name : '',
                from: client.jid.bare,
                fromname: this.props.userInfo.displayName,
                type: this.props.clickedRoster.hasOwnProperty('autoJoin') ? 'groupchat' : 'chat',
                requestReceipt: true,
                chatState: 'active'
        };
        this.props.sendAttachment(messageArr, e.target.files[0]);
    }

    //on submit send message
    handleSubmit(e) {
        e.preventDefault();        
        this.sendMessage();
    }

    //on enter press send text message
    handleTextareaKeypress(event){
        if (event.which == 13 && !event.shiftKey){
            event.preventDefault();  
            this.sendMessage();
        }
    }

    //handling validation and message sending
    sendMessage(){
        if(this.state.message.trim()){
            var msg = {
                id: Object.keys(this.state.oldMessage).length ? this.state.oldMessage.id : client.nextId(),
                to: this.props.clickedRoster.jid.bare,
                toname: this.props.clickedRoster.name ? this.props.clickedRoster.name : '',
                from: client.jid.bare,
                fromname: this.props.userInfo.displayName,
                type: this.props.clickedRoster.hasOwnProperty('autoJoin') ? 'groupchat' : 'chat',
                body: this.state.message,
                requestReceipt: true,
                chatState: 'active',
                oldMessage: this.state.oldMessage,
                //oobURIs: links
            };
            
            this.setState({ message: '', oldMessage: '' });
            if(Object.keys(this.state.oldMessage).length){
                this.props.updateMessage(msg, this.state.notificationUsers);
            }else{
                this.props.addMessage(msg, this.state.notificationUsers);
            }
        }
    }

    //set and get input value
    handleChange(e) {
        this.setState({
            message: e.target.value
        });
    }

    //get users list for @ mention
    getUsersForNotification(value){        
        let users = [];
        users.push({
            toUser: value,
            from: localStorage.name,
            subject: 'Notification from Message Centre',
            desc: ''
        });
        
        this.setState({
            notificationUsers:users
        });
    }

    //on selection on emoji set its value in message
    setEmoji(emoji){
        this.setState({message: this.state.message + '' + emoji.native})
    }

    //track props value change
    componentWillReceiveProps(nextProps) {
        //check if roster data is updated
        if (nextProps.rosterData.all !== this.props.rosterData.all) {
            let rosterData = [];
            _.each(nextProps.rosterData.all, function (item, i) {
                rosterData.push({
                    id: item.jid.bare,
                    display: (item.name ? item.name : item.jid.bare)
                });
            });

            this.setState({
                rosterValues: rosterData
            });
        }

        //check if message is being edited
        if(nextProps.chatData.editmessage !== this.props.chatData.editmessage){
            this.setState({
                message: Object.keys(nextProps.chatData.editmessage).length ? nextProps.chatData.editmessage.body : '',
                oldMessage: nextProps.chatData.editmessage
            });
        }
    }

    render() {
        const { message, rosterValues } = this.state
        return (
            <form name="chat" id="chat" method="post" onSubmit={this.handleSubmit}>
                <Col sm={12} className="msgInputArea">
                  <span className="attach_file">
                    <span className="material-icons">attach_file</span>
                      <FormControl
                        type="file"
                        value={this.state.value}
                        placeholder="Enter text"
                        onChange={this.fileOnChange}
                      />              
                    </span>
                    <FormGroup controlId="formBasicText">
                        <MentionsInput 
                            value={this.state.message}
                            name="message" 
                            placeholder={"Type your message..."}
                            onChange={this.handleChange}
                            displayTransform={ (id, display) => `@${display}` }
                            markup = "@__display__"
                            className="mentions"
                            onKeyPress={this.handleTextareaKeypress} >
                            
                            <Mention trigger="@" data={rosterValues} onAdd={this.getUsersForNotification}  />
                        </MentionsInput>
                    </FormGroup>
                    <EmojiPicker setEmoji={this.setEmoji}/>
                    <Button type="submit" className="send">
                        <span className="material-icons">send</span>
                    </Button>
                </Col>
            </form>
        );
    }
}

export default ChatInsert;
