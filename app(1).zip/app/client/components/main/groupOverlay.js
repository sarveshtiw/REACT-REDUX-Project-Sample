import React, { Component } from 'react';
import { Row, Col } from 'react-bootstrap';

class GroupOverlay extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isShow: false
        };
    }
    render() {
        return (
            <div className="overlayWrapper">
                <div id="groupCreated" className="groupOverlay">
                    <img className="teamIcon pull-left" src="./favicon/master_picture.png" />
                    <div className="titleWrap bottom_margin">
                        <p className="title">
                            <span className="titleOpener">You just created</span>
                            <br />
                            <span className="titlePrefix">#</span>
                            <strong>Testing 123</strong>
                        </p>
                    </div>
                    <ul>
                        <li>Others in your workspace can join from the <strong>Channel List</strong>.</li>
                        <li>Or, you can <a className="bold invite_link">invite other people now</a>!</li>
                    </ul>
                    <p className="groupOverlayPurpose">The purpose of this channel is:<br /><em>Testing</em></p>
                    <label className="checkbox overlayPref block">
                        <input id="noCreatedOverlays" type="checkbox" /> Don't show me this message when I create a channel
                    </label>
                    <a className="btn btn-success">Got it!</a>
                    <p className="hidden" aria-hidden="false">Press enter to close this message and view the channel.</p>
                </div>
            </div>
        );
    }
}
export default GroupOverlay;
