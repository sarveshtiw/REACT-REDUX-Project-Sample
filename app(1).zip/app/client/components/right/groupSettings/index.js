import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class RightSidebar extends Component {

    render() {
        return (
            <div className="col-md-9">
            </div>
        );
    }
}

export default RightSidebar;