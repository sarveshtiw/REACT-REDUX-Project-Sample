import React, { Component } from 'react';
import { Button, FormGroup, FormControl, Row, Col, DropdownButton, MenuItem } from 'react-bootstrap';
import axios from 'axios';
import configData from '../../../data/config';
import messagefilter from '../../../models/messagefilter';

class AddNewMessage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            return_url: ''
        }; 
    }
        
    componentWillMount(){
        var self = this;
        const { chatArray } = this.props;
        var chatbody = chatArray.body;
        if(chatArray.hasOwnProperty("isAttachment") && chatArray.isAttachment === true){
            axios({
                method: 'GET',
                url: configData.api_minio + '/file-get/?file=' + chatbody +"&asergisPopId=india",
                headers: {
                    'token': localStorage.token
                }
            }).then(function(response) {
                self.setState({
                    return_url:response.data.url    
                });
            })
            .catch((error) => {
                console.log(error);
            });
        }
    }    

    componentWillUnmount(){
        var self = this;
        self.setState({
            return_url: ''
        });
    }

    render() {
        const { chatArray, dateObj } = this.props;
        var isAttachment = false;
        let mymsg = (chatArray && chatArray.from.jid === localStorage.jid ? 'next' : '');
        if(chatArray.hasOwnProperty("isAttachment") && chatArray.isAttachment == true){
            isAttachment = true;
        }    
        //for attachment block
        var body = messagefilter.setChatBodyFormat(chatArray, this.state.return_url);        
               
        return (
            <li id={chatArray.id}>
                <div id={chatArray.id} className="sentFile">
                    {
                        isAttachment ?
                        <div>
                            <div className="fileSend" dangerouslySetInnerHTML={{__html: body}}></div>
                            <div className="sentFileDesc">
                                <h4>{chatArray.body}
                                    <DropdownButton noCaret pullRight id="dropdown-btn-menu" bsStyle="link" title="...">
                                        <MenuItem key="1">Share</MenuItem>      
                                        <MenuItem key="2">Download</MenuItem>
                                        <MenuItem key="3" className="delete">Delete</MenuItem>
                                    </DropdownButton>  
                                </h4>
                                <p>{chatArray.from.name}</p>
                                <small>{dateObj.shorttime}</small>
                            </div>
                        </div>
                        : <div>
                             <p className="name">
                                <span className="online"></span>
                                {chatArray.from.name}
                                <span className="date">{dateObj.shorttime}</span>
                            </p>
                            <p className="desc">{chatArray.body}</p>
                        </div>
                    }                     
                     
                </div>
            </li>
        );
    }
}

export default AddNewMessage;