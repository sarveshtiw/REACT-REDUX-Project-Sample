import React, { Component } from 'react';
import {Row,Col,DropdownButton,MenuItem} from 'react-bootstrap';
import AddNewMessage from './addNewMessage';
import messagefilter from '../../../models/messagefilter';

class ConversationDetails extends Component { 
  constructor(props) {
    super(props);
    this.state = {
      starClass: false,
      sharedClass: false
    };
    this.handleClick = this.handleClick.bind(this);
    this.itemsClick  = this.itemsClick.bind(this); 
    this.closePanel = this.closePanel.bind(this);
  }

  itemsClick() {
    this.setState(function(prevState) {
      return {starClass: !prevState.starClass};
    });
    this.getFavChats();
  }

  handleClick() {
    this.setState(function(prevState) {
      return {sharedClass: !prevState.sharedClass};
    });
    this.getAttachments();
  }

  getFavChats(){
    const { clickedRoster, getChatMessagesByCategory } = this.props;
    let data = {isFavourite: true, jid: {bare: clickedRoster.jid.full}};
    getChatMessagesByCategory(data);
  }

  getAttachments() { 
    const { clickedRoster, getChatMessagesByCategory } = this.props;
    let data = {isAttachment: true, jid: {bare: clickedRoster.jid.full}};
    getChatMessagesByCategory(data);
  }

  closePanel() {
    this.setState(function (prevState) {
        return {
            addClass2: !prevState.addClass2
        };
    },() => this.props.infoOpen({
            addClass2: true
    }));
  }

  render() {
    const { chatbody } = this.state;
    const { chatAttachments, chatFavourites, clickedRoster } = this.props;
    const chatAttachData = chatAttachments;
    const chatFavData = chatFavourites;
    var sender    = clickedRoster != null ? clickedRoster.jid.bare : '';
    var chatAttachArray = chatAttachData && chatAttachData.hasOwnProperty(sender) ? chatAttachData[sender] : {};
    var chatFavArray = chatFavData && chatFavData.hasOwnProperty(sender) ? chatFavData[sender] : {};
    var dateArr   = [];
 
    return (
       <Col sm={12} className="rightPannel cDetails">
        <Row>
          <h3 className="clearfix">Conversation details <a href="javascript:void(0);" onClick={this.closePanel}><i className="material-icons">highlight_off</i></a></h3>
          <div className="userName col-sm-12">
            <span className="online"></span>
            <p className="uName">{ clickedRoster ? clickedRoster.jid.local : 'NA'} <span></span></p>
          </div>
          <h4 className="col-sm-12" onClick={this.itemsClick}>
            <i className="material-icons">star_border</i> {Object.keys(chatFavArray).length} starred items
            <i className="material-icons dropDown">arrow_drop_down</i>
          </h4>
          { this.state.starClass && 
            <ul className="favItem stardItem">

              {Object.keys(chatFavArray || {}).map((keyName, keyIndex) => {            
                var chat = chatFavArray.hasOwnProperty(keyName) ? chatFavArray[keyName] : '';                        
                var date = messagefilter.setDataFormat(chatFavArray[keyName].createdOn, dateArr);
                return(
                    <AddNewMessage chatArray={chat} key={keyIndex} dateObj={date}  />
                )
              })}

              {(Object.keys(chatFavArray).length==0) ?
               <li>You haven’t starred any messages.</li>
              :''}

            </ul>
          }

          <h4 className="col-sm-12" onClick={this.handleClick}>
            <i className="material-icons">library_books</i> Shared files
            <i className="material-icons dropDown">arrow_drop_down</i>
          </h4>
          { this.state.sharedClass && 
            <ul className="favItem stardItem">

              {Object.keys(chatAttachArray || {}).map((keyName, keyIndex) => {            
                var chat = chatAttachArray.hasOwnProperty(keyName) ? chatAttachArray[keyName] : '';                        
                var date = messagefilter.setDataFormat(chatAttachArray[keyName].createdOn, dateArr);
                return(
                    <AddNewMessage chatArray={chat} key={keyIndex} dateObj={date}   />
                )
              })}

              {(Object.keys(chatAttachArray).length==0) ?
               <li>There are no files to see here right now! But there could be – upload any file into the message pane to add it to this conversation.</li>
               :''}

            </ul>
          }
        </Row>    
       </Col>
      );
   }
}

export default ConversationDetails;