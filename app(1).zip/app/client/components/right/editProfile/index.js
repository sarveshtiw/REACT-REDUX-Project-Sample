import React, { Component } from 'react';
import { Row, Col, Button, FormGroup, FormControl, ControlLabel, HelpBlock } from 'react-bootstrap';
import { Picker } from 'emoji-mart';
import msgService from './../../../services/message';

function FieldGroup({ id, label, help, ...props }) {
    return (
        <FormGroup controlId={id}>
            <ControlLabel>{label}</ControlLabel>
            <FormControl {...props} />
            {help && <HelpBlock>{help}</HelpBlock>}
        </FormGroup>
    );
}

class EditProfile extends Component {

    constructor(props) {
        super(props);
        this.state = {
            fullName: '', 
            displayName: '',
            status: ''
        };
        this.closePanel = this.closePanel.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.updateProfile = this.updateProfile.bind(this);
    }

    componentDidMount() {
        const { userInfo } = this.props;
        console.log("userInfo",userInfo);
        this.setState({
            fullName: userInfo.fullName, 
            displayName: userInfo.displayName,
            status: userInfo.status
        });
    }
   
    closePanel() {
        this.setState(function (prevState) {
            return {
                addClass3: !prevState.addClass3
            };
        },() => this.props.setOpen({
                addClass3: true
        }));
    }

    handleChange(e) {
        this.setState({
            [e.target.name]: e.target.value
        });
    }

    updateProfile(e) {
        e.preventDefault();
        var fullName = this.state.fullName;
        var displayName = this.state.displayName;
        var status = this.state.status;
        const { userInfo, updateUserStatus } = this.props;
        var data = {fullName: fullName, displayName: displayName};
        this.props.updateUserStatus(userInfo.showtypes, status, data); 
        this.setState({
            fullName: fullName, 
            displayName: displayName,
            status: status
        });
        var jid = localStorage.jid;
        var user = jid.split('@');
        var obj = {name: user[0], host: user[1], nickname: displayName};
        msgService.sendNickname(obj);
    }

    render() {
        return (
            <Col sm={12} className="rightPannel editProfile">
                <Row>
                    <h3>Edit Your Profile <a href="javascript:void(0);" onClick={this.closePanel}><i className="material-icons">highlight_off</i></a></h3>
                </Row>
                <form className="updateUserProfile" method="post" onSubmit={this.updateProfile}>
                    <FieldGroup
                        type="text"
                        label="Full name"
                        placeholder="Enter Full name"
                        id="fullName" name="fullName" onChange={this.handleChange} value={this.state.fullName} required
                    />
                    <FieldGroup
                        type="text"
                        label="Display name"
                        placeholder="Enter Display name"
                        id="displayName" name="displayName" onChange={this.handleChange} value={this.state.displayName} required
                    />
                    <div className="form-group status">
                        <ControlLabel>Status</ControlLabel>
                        <FormControl 
                            type="text" 
                            placeholder="Enter Status" 
                            id="status" name="status" onChange={this.handleChange} value={this.state.status} required
                        />
                    </div>
                    <div className="btn-wrap">
                        <Button type="button" className="cancel" onClick={this.closePanel}>Cancel</Button>
                        <Button type="submit" className="save">Save changes</Button>
                    </div>
                </form>
            </Col>
        );
    }
}

export default EditProfile;