import React, { Component } from 'react';
import { Col } from 'react-bootstrap';
import { Scrollbars } from 'react-custom-scrollbars';

import EditProfile from '../right/editProfile';
import ConversationDetails from '../right/conversationDetails';

class Right extends Component {
    
    render() {
        
        return (
            <Col sm={3} className="rightSidebar">
                <Scrollbars className="rightScroll row" style={{ height: '100%' }} autoHide autoHeight autoHeightMin={300} >
                    <EditProfile 
                        settOpen={this.props.settOpen} 
                        updateUserStatus={this.props.updateUserStatus}
                        getUserStatus={this.props.getUserStatus} 
                    />
                    <ConversationDetails />
                </Scrollbars>
            </Col>
        );
    }
}
export default Right;