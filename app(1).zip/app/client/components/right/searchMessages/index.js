import React, { Component } from 'react';
import { Row, Col, DropdownButton, MenuItem } from 'react-bootstrap';
import Moment from 'moment';

class Search extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };

        this.setDataFormat = this.setDataFormat.bind(this);
        this.closePanel = this.closePanel.bind(this);
    }

    setDataFormat(datetime){
        var msgtime='';
        //for time header
        if(Moment(datetime).format('MMMM, dddd Do') == Moment().format('MMMM, dddd Do')){
             msgtime = 'Today';

        }else if(Moment(datetime).format('MMMM, dddd Do') == Moment().add(-1, 'days').format('MMMM, dddd Do')){
             msgtime = 'Yesterday';
        }else{
             msgtime = Moment(datetime).format('MMMM, dddd Do');
        }
        return {msgtime: msgtime}
    }

    closePanel() {
        this.setState(function (prevState) {
            return {
                searchBox: false
            };
        },() => this.props.searchBoxOpen({
            searchBox: false
        }));
    }

    render() {
        const {searchData} = this.props;
        return (
          <Col sm={12} className="rightPannel cDetails">
            <Row>
                <h3 className="clearfix">Search results <a href="javascript:void(0);" onClick={this.closePanel}><i className="material-icons">highlight_off</i></a></h3>
                <ul className="favItem stardItem">
                    {Object.keys(searchData || {}).map((keyName, keyIndex) => {
                        const date = this.setDataFormat(searchData[keyIndex].createdOn);
                        
                        return (
                          <li className="clearfix" key={keyIndex}>
                            {/*<h5>#sarvesh</h5>*/}
                            <div className="userIcon pull-left">{searchData[keyIndex].from.jid.substr(0, 1).toUpperCase()}</div>
                            <div className="msgDesc">
                              <p className="name">
                                  {/*<span className="online"></span>*/}
                                  {searchData[keyIndex].from.name}
                                  <span className="date">{date.msgtime}</span>
                              </p>
                              <p className="desc">{searchData[keyIndex].body}</p>
                            </div>
                          </li>
                        )
                    })}
                </ul>
            </Row>
          </Col>
        );
    }
}    

export default Search;