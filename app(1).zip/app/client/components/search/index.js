import React, { Component } from 'react';
import {FormGroup, FormControl, Row, Col } from 'react-bootstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import onClickOutside from 'react-onclickoutside';

class Search extends Component {
    constructor(props) {
        super(props);
        this.state = {
            memberList: false,
            inChat: false,
            popoverMenu: false,
            search: ''
        };

        this.memberList = this.memberList.bind(this);
        this.inChat = this.inChat.bind(this);
        this.setSearchFilter = this.setSearchFilter.bind(this);
        this.popoverShow = this.popoverShow.bind(this);
        this.setInput = this.setInput.bind(this);
    }

    popoverShow() {
        this.setState({
            popoverMenu: true
        });
    }

    memberList() {
        this.setState({
            memberList: true,
        });
    }

    inChat() {
        this.setState({
            inChat: true,
        });
    }

    setSearchFilter(type, name) { 
        if(name == 'date'){
            var filter = type + ': ';
        }else{
            var filter = type + ': ' + name + ': ' ;
        }       
        
        console.log(filter);
        this.setState({
            search: filter 
        })        
    }

    setInput(event) {
        this.setState({
            search: event.target.value
        });
    }

    handleClickOutside(evt) {
        // ..handling code goes here...
        this.setState(function (prevState) {
            return { 
                popoverMenu: prevState.popoverMenu ? !prevState.popoverMenu : prevState.popoverMenu,
                memberList: prevState.memberList ? !prevState.memberList : prevState.memberList,
                inChat: prevState.inChat ? !prevState.inChat : prevState.inChat,
            };
        });
    }

    render() {
        
        const {rosterData, roomsData} = this.props;
        return (

            <FormGroup controlId="formBasicText" className="btnGroup" style={{ 'width': this.state.popoverStyle }} className={!this.state.popoverMenu ? "btnGroup" : "btnGroup focus"}>
                <form name="search-message" onSubmit={this.props.handleSearch} autoComplete="off">
                    <FormControl type="text" name="searchinput" placeholder="Search" onChange={this.setInput} value={this.state.search} onFocus={this.popoverShow} ></FormControl>
                    <span className="form-control-feedback material-icons">search</span>
                </form>
                {this.state.popoverMenu &&

                <div className="popover_menu popover_search_menu showing_header" id="search_autocomplete_popover">
                    <div id="autocomplete_menu" className="content search_menu">
                        <Scrollbars autoHide autoHeight autoHeightMin={0} autoHeightMax={'360px'} >
                            {!(this.state.memberList || this.state.inChat) &&
                                <div>
                                    <header>
                                        <span className="headerLabel">
                                            <span className="headerLabelText"> Narrow your search</span>
                                            <hr className="" />
                                        </span>
                                        <a className="learnMoreLink" href="" tabIndex="-1">
                                            <i className="material-icons">info_outline</i>
                                        </a>
                                    </header>
                                    <ul className="">
                                        <li>
                                            <button className="resultItemBtn btnUnstyle" type="button" tabIndex="-1" onClick={this.memberList}>
                                                <strong>from: </strong>
                                                <span className="text-muted">member</span>
                                            </button>
                                        </li>
                                        <li>
                                            <button className="resultItemBtn btnUnstyle" type="button" tabIndex="-1" onClick={this.inChat}>
                                                <strong>in: </strong>
                                                <span className="text-muted">channel or direct message</span>
                                            </button>
                                        </li>
                                    </ul>
                                    <ul className="time_modifiers">
                                        <li>
                                            <button className="resultItemBtn btnUnstyle" type="button" tabIndex="-1" onClick={()=>this.setSearchFilter('after', 'date')}>
                                                <strong>after: </strong>
                                                <span className="text-muted">mm/dd/yyyy</span>
                                            </button>
                                        </li>
                                        <li>
                                            <button className="resultItemBtn btnUnstyle" type="button" tabIndex="-1" onClick={()=>this.setSearchFilter('before', 'date')}>
                                                <strong>before: </strong>
                                                <span className="text-muted">mm/dd/yyyy</span>
                                            </button>
                                        </li>
                                        <li>
                                            <button className="resultItemBtn btnUnstyle" type="button" tabIndex="-1" onClick={()=>this.setSearchFilter('on-date', 'date')}>
                                                <strong>on: </strong>
                                                <span className="text-muted">mm/dd/yyyy</span>
                                            </button>
                                        </li>
                                    </ul>
                                </div>
                            }
                            {this.state.inChat &&
                                <div>
                                    <header className="channelsH">
                                        <span className="headerLabel">
                                            <span className="headerLabelText"> Groups</span>
                                            <hr className="" />
                                        </span>
                                    </header>
                                    <ul className="channels">
                                    {Object.keys(roomsData || {}).map((keyName, keyIndex) => {
                                        return (
                                            <li key={keyIndex}>
                                                <button className="resultItemBtn btnUnstyle" type="button" tabIndex="-1" onClick={()=>this.setSearchFilter('in-group', roomsData[keyIndex].jid.local)}>
                                                    <strong>{roomsData[keyName].name}</strong>
                                                </button>
                                            </li>
                                        )     
                                    })}                                       
                                    </ul>
                                    <header className="membersH">
                                        <span className="headerLabel">
                                            <span className="headerLabelText"> Members</span>
                                            <hr className="" />
                                        </span>
                                    </header>
                                    <ul className="members">
                                    {Object.keys(rosterData || {}).map((keyName, keyIndex) => {
                                        return (
                                            <li key={keyIndex}>
                                                <button className="resultItemBtn btnUnstyle" type="button" tabIndex="-1" onClick={()=>this.setSearchFilter('in-member', rosterData[keyIndex].jid.local)}>
                                                    <strong>{rosterData[keyIndex].jid.local}</strong>
                                                </button>
                                            </li> 
                                        ) 
                                    })}                                      
                                    </ul>
                                </div>
                            }                            
                            {this.state.memberList &&
                                <div>
                                    <header>
                                        <span className="headerLabel">
                                            <span className="headerLabelText">
                                                Members</span>
                                            <hr className="" />
                                        </span>
                                    </header>
                                    <ul className="memberList">
                                    {Object.keys(rosterData || {}).map((keyName, keyIndex) => {
                                        return (
                                            <li key={keyIndex}>
                                                <div className="userIcon pull-left">{rosterData[keyIndex].jid.local.substr(0, 1).toUpperCase()}</div>
                                                <div className="msgDesc">
                                                    <p className="name" onClick={()=>this.setSearchFilter('from', rosterData[keyIndex].jid.local)}>
                                                        {rosterData[keyIndex].jid.local}
                                                        {/*<span className="title">{rosterData[keyIndex].jid.local}</span>*/}
                                                    </p>
                                                </div>
                                            </li>
                                        )
                                    })}                                        
                                    </ul>
                                </div>
                            }
                        </Scrollbars>
                    </div>
                </div>
            }
            </FormGroup>
        )
    }
}
export default onClickOutside(Search);