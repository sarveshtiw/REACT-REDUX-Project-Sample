import React, { Component } from 'react';

class Test extends React.Component {

    constructor(props) {
      super(props);
      this.state = {"test": 0, "count": 0};
    }
    
    componentWillMount(){
      console.log("WillMount", this.state);
    }

    componentDidMount(){
      console.log("DidMount", this.state);      
    }
    
    componentWillUpdate(){
      console.log("WillUpdate", this.state);
    }

    componentDidUpdate(){
      console.log("DidUpdate", this.state);      
    }

    componentWillReceiveProps(nextProps){
      const { handle } = this.props;
      console.log("nextProps",nextProps, nextProps.handle.test);
      if(nextProps.handle.test !==  this.state.test){
        this.setState({"count": nextProps.handle.test});
      }
    }

    render() {
       const { handle } = this.props;
       //console.log("handle", this.state, handle);
       return(
          <div>
            <center><h1> Welcome to test page</h1></center>
          </div>
       )
    }
}

export default Test;
