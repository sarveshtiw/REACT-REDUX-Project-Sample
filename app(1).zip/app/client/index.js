import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import { applyMiddleware } from 'redux';
// import react router deps
import { Router, Route, IndexRoute, browserHistory } from 'react-router';

// Import Components
import App from './containers/App';
import Welcome from './components/Welcome';
import Dashboard from './components/Dashboard';
import reduxThunk from 'redux-thunk';
import store, { history } from './store';
import './scss/App.scss';

const router = (
	<Provider store={store}>
	  <Router history={browserHistory}>
	    <Route path="/" component={App}>
	      <IndexRoute component={Dashboard}/>
	    </Route>			
			<Route path="/welcome" component={Welcome}/>
	  </Router>
  </Provider>
)

render(router, document.getElementById('root'));
