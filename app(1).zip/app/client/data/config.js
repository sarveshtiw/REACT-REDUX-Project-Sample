const configData = {
    'api_url': process.env.API_URL,
    'api_minio': process.env.API_MINIO,
    'amp_api': process.env.AMP_API,
    'document': {
        'user': 'userinfo',
        'chat': 'chatdata',
        'notifications': 'notifications'
    },
    'email':{
        'from': 'support@asergis.com',
    },
    'email_host': 'http://localhost:3002',
    'cm_graphql_endpoint' : 'http://localhost:5000/contact_manager'
}

export default configData;