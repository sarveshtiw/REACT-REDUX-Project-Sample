const rooms = {
    "conferences": [
        {
            'name': "India Group",
            'jid': {
                'bare': "india@conference.asergis.com",
                'local': "india"
            },
            'nick': "india conf",
            'autoJoin': true,
            'unread': 0
        },
        {
            'name': "Malta Group",
            'jid': {
                'bare': "malta@conference.asergis.com",
                'local': "malta"
            },
            'nick': "malta conf",
            'autoJoin': true,
            'unread': 0
        },
        {
            'name': "UK Group",
            'jid': {
                'bare': "ukgrp@conference.asergis.com",
                'local': "uk"
            },
            'nick': "uk conf",
            'autoJoin': true,
            'unread': 0
        }
    ]
};

export default rooms;