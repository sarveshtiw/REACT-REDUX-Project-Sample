const emailLists = {
    'emails': [
        {
            'ampLoggedUser': 'sarvesh.tiwari@asergis.in',
            'mcaLoggedUser': 'sarvesh@asergis.com'
        },
        {
            'ampLoggedUser': 'ravi.kant@asergis.in',
            'mcaLoggedUser': 'ravi@asergis.com'
        },
        {
            'ampLoggedUser': 'khushboo.verma@asergis.in',
            'mcaLoggedUser': 'khushboo@asergis.com'
        }
    ]
};

export default emailLists;